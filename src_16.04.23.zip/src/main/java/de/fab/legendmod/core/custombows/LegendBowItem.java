 package de.fab.legendmod.core.custombows;
 import net.minecraft.enchantment.EnchantmentHelper;
 import net.minecraft.enchantment.Enchantments;
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.LivingEntity;
 import net.minecraft.entity.player.PlayerEntity;
 import net.minecraft.entity.projectile.AbstractArrowEntity;
 import net.minecraft.item.ArrowItem;
 import net.minecraft.item.BowItem;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 import net.minecraft.item.Items;
 import net.minecraft.stats.Stats;
 import net.minecraft.tags.ITag;
 import net.minecraft.tags.ItemTags;
 import net.minecraft.util.IItemProvider;
 import net.minecraft.util.SoundCategory;
 import net.minecraft.util.SoundEvents;
 import net.minecraft.world.World;
 import net.minecraftforge.event.ForgeEventFactory;

 import java.util.function.Predicate;

 public class LegendBowItem extends BowItem {
   public LegendBowItem(Item.Properties p_i48522_1_) {
     super(p_i48522_1_);
   }
 
   
   public void onPlayerStoppedUsing(ItemStack bowStack, World worldIn, LivingEntity entityLiving, int timeLeft) {
     if (entityLiving instanceof PlayerEntity) {
       PlayerEntity playerentity = (PlayerEntity)entityLiving;
       boolean hasInfinity = (playerentity.abilities.isCreativeMode || EnchantmentHelper.getEnchantmentLevel(Enchantments.INFINITY, bowStack) > 0);
       ItemStack ammoStack = playerentity.findAmmo(bowStack);
       
       int timeDrawn = getUseDuration(bowStack) - timeLeft;
       timeDrawn = ForgeEventFactory.onArrowLoose(bowStack, worldIn, playerentity, timeDrawn, (!ammoStack.isEmpty() || hasInfinity));
       if (timeDrawn < 0)
         return; 
       if (!ammoStack.isEmpty() || hasInfinity) {
         boolean isTippedArrow = (ammoStack.getItem() == Items.SPECTRAL_ARROW || ammoStack.getItem() == Items.TIPPED_ARROW);
         
         if (ammoStack.isEmpty()) {
           ammoStack = new ItemStack((IItemProvider)Items.ARROW);
         }
         
         float velocity = getArrowVelocity(timeDrawn);
         if (velocity >= 0.1D) {
           if (!worldIn.isRemote) {
             AbstractArrowEntity arrowEntity = createArrow(worldIn, ammoStack, playerentity);
             
             arrowEntity = customArrow(arrowEntity);
             arrowEntity.setDirectionAndMovement(playerentity,playerentity.rotationPitch, playerentity.rotationYaw, 0.0F, velocity * 3.0F, 1.0F);
             
             if (velocity == 1.0F) arrowEntity.setIsCritical(true);
             
             double damage = getArrowDamage(bowStack, arrowEntity);
             arrowEntity.setDamage(damage);
             
             int knockback = getArrowKnockback(bowStack, arrowEntity);
             arrowEntity.setKnockbackStrength(knockback);
 
             
             if (EnchantmentHelper.getEnchantmentLevel(Enchantments.FLAME, bowStack) > 0) {
               arrowEntity.setFire(100);
             }
 
             
             bowStack.damageItem(1, (LivingEntity)playerentity, p_220009_1_ -> p_220009_1_.sendBreakAnimation(playerentity.getActiveHand()));
 
 
 
             
             if (hasInfinity && !isTippedArrow) {
               arrowEntity.pickupStatus = AbstractArrowEntity.PickupStatus.CREATIVE_ONLY;
             }
 
             
             worldIn.addEntity((Entity)arrowEntity);
           } 
 
           
           worldIn.playSound((PlayerEntity)null, playerentity.getPosX(), playerentity.getPosY(), playerentity.getPosZ(), SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.0F, 1.0F / (random.nextFloat() * 0.4F + 1.2F) + velocity * 0.5F);
 
           
           boolean shouldConsumeArrow = (!hasInfinity || isTippedArrow);
           if (shouldConsumeArrow) {
             ammoStack.shrink(1);
             if (ammoStack.isEmpty()) {
               playerentity.inventory.deleteStack(ammoStack);
             }
           } 
           
           playerentity.addStat(Stats.ITEM_USED.get(this));
         } 
       } 
     } 
   }
 
   
   protected AbstractArrowEntity createArrow(World worldIn, ItemStack ammoStack, PlayerEntity playerentity) {
     ArrowItem arrowitem = (ammoStack.getItem() instanceof ArrowItem) ? (ArrowItem)ammoStack.getItem() : (ArrowItem)Items.ARROW;
     return arrowitem.createArrow(worldIn, ammoStack, (LivingEntity)playerentity);
   }
   
   protected double getArrowDamage(ItemStack bowStack, AbstractArrowEntity arrowEntity) {
     int powerLevel = EnchantmentHelper.getEnchantmentLevel(Enchantments.POWER, bowStack);
     
     if (powerLevel > 0) return arrowEntity.getDamage() + powerLevel * 0.5D + 0.5D; 
     return arrowEntity.getDamage();
   }
   
   protected int getArrowKnockback(ItemStack bowStack, AbstractArrowEntity arrowEntity) {
     return EnchantmentHelper.getEnchantmentLevel(Enchantments.PUNCH, bowStack);
   }
 
   
   public Predicate<ItemStack> getInventoryAmmoPredicate() {
     return ammoStack -> ammoStack.getItem().isIn((ITag)ItemTags.ARROWS);
   }
 }




 
 