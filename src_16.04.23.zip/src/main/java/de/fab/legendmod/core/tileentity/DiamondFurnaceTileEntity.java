package de.fab.legendmod.core.tileentity;

import net.minecraft.tileentity.FurnaceTileEntity;
public class DiamondFurnaceTileEntity extends FurnaceTileEntity {



}
