 package de.fab.legendmod.core.custombows.citrinstar;
 
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.LivingEntity;
 import net.minecraft.entity.player.PlayerEntity;
 import net.minecraft.entity.projectile.SnowballEntity;
 import net.minecraft.item.ItemStack;
 import net.minecraft.item.Items;
 import net.minecraft.nbt.CompoundNBT;
 import net.minecraft.potion.*;
 import net.minecraft.util.math.EntityRayTraceResult;
 import net.minecraft.world.World;

 import javax.naming.CompoundName;
 import java.util.*;


 public class CitrinStarEntity
   extends SnowballEntity
 {
   public CitrinStarEntity(World p_i1774_1_, LivingEntity p_i1774_2_) {
     super(p_i1774_1_, p_i1774_2_);
     EffectInstance Test = new EffectInstance(Effects.REGENERATION, 200, 1);
   }
 
 
 
   
   protected void onEntityHit(EntityRayTraceResult result) {
     super.onEntityHit(result);

     Entity entity = result.getEntity();
     int i = (entity instanceof LivingEntity) ? 1 : 0;
     if (i == 1){
       Map<Effect, Effect> effectOpposites = new HashMap<>();
       effectOpposites.put(Effects.BLINDNESS, Effects.NIGHT_VISION);
       effectOpposites.put(Effects.NIGHT_VISION, Effects.BLINDNESS);
       effectOpposites.put(Effects.POISON, Effects.REGENERATION);
       effectOpposites.put(Effects.REGENERATION, Effects.POISON);
       effectOpposites.put(Effects.WEAKNESS, Effects.STRENGTH);
       effectOpposites.put(Effects.STRENGTH, Effects.WEAKNESS);
       effectOpposites.put(Effects.SLOWNESS, Effects.SPEED);
       effectOpposites.put(Effects.SPEED, Effects.SLOWNESS);
       effectOpposites.put(Effects.FIRE_RESISTANCE, Effects.FIRE_RESISTANCE);
       for (Map.Entry<Effect, Effect> entry : effectOpposites.entrySet()) {
         Effect effect = entry.getKey();
         Effect oppositeEffect = entry.getValue();
         boolean shouldContinue = false;
         if (((LivingEntity) entity).isPotionActive(effect)) {

           EffectInstance effectInstance = ((LivingEntity) entity).getActivePotionEffect(effect);
           for(ItemStack curativeItem : effectInstance.getCurativeItems()){
             if(curativeItem.getItem() == Items.POTION){
               if(curativeItem.getTag().getBoolean("isOldEffect")){
                 shouldContinue = true;
               }
             }
           }
           if(shouldContinue){
             continue;
           }
           int level = effectInstance.getAmplifier();
           int remainingDuration = effectInstance.getDuration();

           ((LivingEntity) entity).removePotionEffect(effect);
           EffectInstance oppositeEffectInstance = new EffectInstance(oppositeEffect, 200, level);
             List<ItemStack> list = new ArrayList<>();
             ItemStack oldPotion = new ItemStack(Items.POTION);
             PotionUtils.addPotionToItemStack(oldPotion, Potions.WATER);
             PotionUtils.appendEffects(oldPotion, Arrays.asList(effectInstance));
             CompoundNBT nbt = oldPotion.getTag();
             nbt.putBoolean("isOldEffect", true);
             oldPotion.setTag(nbt);
             list.add(oldPotion);
             oppositeEffectInstance.setCurativeItems(list);
           ((LivingEntity) entity).addPotionEffect(oppositeEffectInstance);
         } else if (((LivingEntity) entity).isPotionActive(oppositeEffect)) {
           EffectInstance effectInstance = ((LivingEntity) entity).getActivePotionEffect(oppositeEffect);
           for(ItemStack curativeItem : effectInstance.getCurativeItems()){
             if(curativeItem.getItem() == Items.POTION){
               if(curativeItem.getTag().getBoolean("isOldEffect")){
                 shouldContinue = true;
               }
             }
           }
           if(shouldContinue){
             continue;
           }
           int level = effectInstance.getAmplifier();
           int remainingDuration = effectInstance.getDuration();

           ((LivingEntity) entity).removePotionEffect(oppositeEffect);
           EffectInstance newEffectInstance = new EffectInstance(effect, 200, level);
             List<ItemStack> list = new ArrayList<>();
             ItemStack oldPotion = new ItemStack(Items.POTION);
             PotionUtils.addPotionToItemStack(oldPotion, Potions.WATER);
             PotionUtils.appendEffects(oldPotion, Arrays.asList(effectInstance));
             CompoundNBT nbt = oldPotion.getTag();
             nbt.putBoolean("isOldEffect", true);
             oldPotion.setTag(nbt);
             list.add(oldPotion);
             newEffectInstance.setCurativeItems(list);
           ((LivingEntity) entity).addPotionEffect(newEffectInstance);
         }
       }

       if (((LivingEntity) entity).isBurning()) {
         entity.extinguish();
         ((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.FIRE_RESISTANCE, 200, 0));
       } else if (((LivingEntity) entity).isPotionActive(Effects.FIRE_RESISTANCE)) {
         ((LivingEntity) entity).removePotionEffect(Effects.FIRE_RESISTANCE);
         entity.setFire(10);
       }
       if (entity instanceof PlayerEntity) {
         PlayerEntity playerEntity = (PlayerEntity) entity;
         if(playerEntity.getFoodStats().needFood()){
           ((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.SATURATION, 200, 0));
         } else {
           ((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.HUNGER, 200, 0));
         }
       }
     }
   }
 }




 
 