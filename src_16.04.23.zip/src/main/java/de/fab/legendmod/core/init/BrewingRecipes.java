package de.fab.legendmod.core.init;

import de.fab.legendmod.core.recipe.LingeringPotionBrewingRecipe;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtils;
import net.minecraft.potion.Potions;
import net.minecraft.util.registry.Registry;
import net.minecraftforge.common.brewing.BrewingRecipeRegistry;

public class BrewingRecipes {

    public static void registerLingeringPotionRecipes(Item ingredient) {
        for (Potion potion : Registry.POTION) {
            if (potion != Potions.EMPTY) {
                ItemStack input = new ItemStack(Items.SPLASH_POTION);
                input = PotionUtils.addPotionToItemStack(input, potion);
                ItemStack output = new ItemStack(Items.LINGERING_POTION);
                output = PotionUtils.addPotionToItemStack(output, potion);
                BrewingRecipeRegistry.addRecipe(new LingeringPotionBrewingRecipe(input, new ItemStack(ingredient), output));
            }
        }
    }

}
