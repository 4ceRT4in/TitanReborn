 package de.fab.legendmod.core.init;
 
 import de.fab.legendmod.common.material.CustomToolMaterial;
 import de.fab.legendmod.core.itemgroup.LegendModItemGroup;
 import net.minecraft.item.IItemTier;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemGroup;
 import net.minecraft.item.SwordItem;
 import net.minecraftforge.fml.RegistryObject;
 import net.minecraftforge.registries.DeferredRegister;
 import net.minecraftforge.registries.ForgeRegistries;
 
 public class VanillaItemInit {
   public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, "minecraft");
   
   public static final RegistryObject<Item> WOODEN_SWORD = ITEMS.register("wooden_sword", () -> new SwordItem((IItemTier)CustomToolMaterial.WOOD, 3, 9996.0F, (new Item.Properties().group(ItemGroup.COMBAT))));
 
   
   public static final RegistryObject<Item> GOLDEN_SWORD = ITEMS.register("golden_sword", () -> new SwordItem((IItemTier)CustomToolMaterial.GOLD, 3, 9996.0F, (new Item.Properties().group(ItemGroup.COMBAT))));
 
   
   public static final RegistryObject<Item> STONE_SWORD = ITEMS.register("stone_sword", () -> new SwordItem((IItemTier)CustomToolMaterial.STONE, 4, 9996.0F, (new Item.Properties().group(ItemGroup.COMBAT))));
 
   
   public static final RegistryObject<Item> IRON_SWORD = ITEMS.register("iron_sword", () -> new SwordItem((IItemTier)CustomToolMaterial.IRON, 5, 9996.0F, (new Item.Properties().group(ItemGroup.COMBAT))));
 
   
   public static final RegistryObject<Item> DIAMOND_SWORD = ITEMS.register("diamond_sword", () -> new SwordItem((IItemTier)CustomToolMaterial.DIAMOND, 6, 9996.0F, (new Item.Properties().group(ItemGroup.COMBAT))));
 
   
   public static final RegistryObject<Item> NETHERITE_SWORD = ITEMS.register("netherite_sword", () -> new SwordItem((IItemTier)CustomToolMaterial.NETHERITE, 8, 9996.0F, (new Item.Properties().group(ItemGroup.COMBAT))));
 }




 
 