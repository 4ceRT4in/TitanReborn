 package de.fab.legendmod.core.effectswords.Legend;
 
 import de.fab.legendmod.core.effectswords.LegendSwordItem;
 import java.util.List;
 import java.util.Random;
 import javax.annotation.Nullable;
 import net.minecraft.client.util.ITooltipFlag;
 import net.minecraft.entity.LivingEntity;
 import net.minecraft.item.IItemTier;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 import net.minecraft.potion.EffectInstance;
 import net.minecraft.potion.Effects;
 import net.minecraft.util.text.ITextComponent;
 import net.minecraft.util.text.TranslationTextComponent;
 import net.minecraft.world.World;
 
 public class Legend2Weak extends LegendSwordItem {
   public Legend2Weak(IItemTier p_i48460_1_, int p_i48460_2_, float p_i48460_3_, Item.Properties p_i48460_4_) {
     super(p_i48460_1_, p_i48460_2_, p_i48460_3_, p_i48460_4_);
   }
 
 
 
   
   public boolean hitEntity(ItemStack stack, LivingEntity target, LivingEntity attacker) {
     if (!target.isPotionActive(Effects.WEAKNESS)) {
 
       
       Random rand2 = new Random();
       int upperbound2 = 4;
       int int_random2 = rand2.nextInt(upperbound2);
       if (int_random2 == 0 || int_random2 == 1) {
         target.addPotionEffect(new EffectInstance(Effects.WEAKNESS, 100, 0));
       }
     } 
 
     
     return super.hitEntity(stack, target, attacker);
   }
 
 
 
 
   
   public void addInformation(ItemStack p_77624_1_, @Nullable World p_77624_2_, List<ITextComponent> tooltip, ITooltipFlag p_77624_4_) {
     tooltip.add(new TranslationTextComponent("tooltip.legendmod.2Weak"));
     super.addInformation(p_77624_1_, p_77624_2_, tooltip, p_77624_4_);
   }
 }




 
 