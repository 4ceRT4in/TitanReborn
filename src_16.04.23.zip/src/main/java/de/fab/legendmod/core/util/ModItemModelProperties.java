 package de.fab.legendmod.core.util;
 import net.minecraft.client.world.ClientWorld;
 import net.minecraft.entity.LivingEntity;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemModelsProperties;
 import net.minecraft.item.ItemStack;
 import net.minecraft.util.ResourceLocation;
 
 public class ModItemModelProperties {
   public static void makeBow(Item item) {
     ItemModelsProperties.registerProperty(item, new ResourceLocation("pull"), (p_239429_0_, p_239429_1_, p_239429_2_) -> (p_239429_2_ == null) ? 0.0F : ((p_239429_2_.getActiveItemStack() != p_239429_0_) ? 0.0F : ((p_239429_0_.getUseDuration() - p_239429_2_.getItemInUseCount()) / 20.0F)));
 
 
 
 
 
 
     
     ItemModelsProperties.registerProperty(item, new ResourceLocation("pulling"), (p_239428_0_, p_239428_1_, p_239428_2_) -> 
         (p_239428_2_ != null && p_239428_2_.isHandActive() && p_239428_2_.getActiveItemStack() == p_239428_0_) ? 1.0F : 0.0F);
   }
 
 
   
   public static void makeShield(Item item) {
     ItemModelsProperties.registerProperty(item, new ResourceLocation("blocking"), (p_239421_0_, p_239421_1_, p_239421_2_) -> 
         (p_239421_2_ != null && p_239421_2_.isHandActive() && p_239421_2_.getActiveItemStack() == p_239421_0_) ? 1.0F : 0.0F);
   }
 }




 
 