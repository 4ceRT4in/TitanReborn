 package de.fab.legendmod.core.Ores;
 
 import java.util.Random;
 import net.minecraft.block.AbstractBlock;
 import net.minecraft.block.OreBlock;
 import net.minecraft.util.math.MathHelper;
 
 public class NetherOre extends OreBlock {
   public NetherOre(AbstractBlock.Properties p_i48357_1_) {
     super(p_i48357_1_);
   }
 
 
   
   protected int func_220281_a(Random rand) {
     return MathHelper.nextInt(rand, 2, 5);
   }
 }




 
 