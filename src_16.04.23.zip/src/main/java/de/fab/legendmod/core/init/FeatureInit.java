 package de.fab.legendmod.core.init;
 import net.minecraft.block.Block;
 import net.minecraft.block.BlockState;
 import net.minecraft.world.gen.GenerationStage;
 import net.minecraft.world.gen.feature.ConfiguredFeature;
 import net.minecraft.world.gen.feature.Feature;
 import net.minecraft.world.gen.feature.IFeatureConfig;
 import net.minecraft.world.gen.feature.OreFeatureConfig;
 import net.minecraft.world.gen.feature.template.RuleTest;
 import net.minecraft.world.gen.placement.IPlacementConfig;
 import net.minecraft.world.gen.placement.Placement;
 import net.minecraft.world.gen.placement.TopSolidRangeConfig;
 import net.minecraftforge.event.world.BiomeLoadingEvent;
 
 public class FeatureInit {
   public static void addOres(BiomeLoadingEvent event) {
     addOre(event, OreFeatureConfig.FillerBlockType.BASE_STONE_OVERWORLD, ((Block)BlockInit.CITRIN_ORE.get()).getDefaultState(), 9, 0, 48, 10);
     addOre(event, OreFeatureConfig.FillerBlockType.BASE_STONE_OVERWORLD, ((Block)BlockInit.LEGEND_ORE.get()).getDefaultState(), 8, 0, 16, 1);
     addOre(event, OreFeatureConfig.FillerBlockType.BASE_STONE_NETHER, ((Block)BlockInit.NETHER_ORE.get()).getDefaultState(), 9, 0, 130, 10);
   }
   
   public static void addOre(BiomeLoadingEvent event, RuleTest rule, BlockState state, int veinSize, int minHeight, int maxHeiht, int amount) {
     event.getGeneration().withFeature(GenerationStage.Decoration.UNDERGROUND_ORES, (ConfiguredFeature)((ConfiguredFeature) Feature.ORE
         .withConfiguration(new OreFeatureConfig(rule, state, veinSize))
         .withPlacement(Placement.RANGE.configure(new TopSolidRangeConfig(minHeight, 0, maxHeiht)))).range(amount));
   }
 }




 
 