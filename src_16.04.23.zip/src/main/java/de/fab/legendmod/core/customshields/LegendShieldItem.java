    package de.fab.legendmod.core.customshields;
    import net.minecraft.item.Item;
    import net.minecraft.item.ShieldItem;

    public class LegendShieldItem extends ShieldItem {
      public LegendShieldItem(Item.Properties p_i48470_1_) {
     super(p_i48470_1_);
     }
    }




 
 