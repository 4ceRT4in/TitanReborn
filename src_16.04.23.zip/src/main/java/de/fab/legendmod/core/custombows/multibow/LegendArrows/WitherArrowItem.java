 package de.fab.legendmod.core.custombows.multibow.LegendArrows;
 
 import de.fab.legendmod.core.custombows.EffectArrowItem;
 import java.util.List;
 import javax.annotation.Nullable;
 import net.minecraft.client.util.ITooltipFlag;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 import net.minecraft.util.text.ITextComponent;
 import net.minecraft.util.text.TranslationTextComponent;
 import net.minecraft.world.World;
 
 public class WitherArrowItem extends EffectArrowItem {
   public WitherArrowItem(Item.Properties p_i48531_1_) {
     super(p_i48531_1_);
   }
 
 
   
   public void addInformation(ItemStack p_77624_1_, @Nullable World p_77624_2_, List<ITextComponent> tooltip, ITooltipFlag p_77624_4_) {
     tooltip.add(new TranslationTextComponent("tooltip.legendmod.witherArrowItem"));
     super.addInformation(p_77624_1_, p_77624_2_, tooltip, p_77624_4_);
   }
 }




 
 