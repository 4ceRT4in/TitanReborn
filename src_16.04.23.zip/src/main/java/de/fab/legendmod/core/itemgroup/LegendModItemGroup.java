 package de.fab.legendmod.core.itemgroup;
 
 import de.fab.legendmod.core.init.ItemInit;
 import net.minecraft.item.ItemGroup;
 import net.minecraft.item.ItemStack;
 import net.minecraft.util.IItemProvider;
 
 public class LegendModItemGroup extends ItemGroup {
   public static final LegendModItemGroup LEGEND_MOD = new LegendModItemGroup(ItemGroup.GROUPS.length, "legend_mod");
 
   
   public LegendModItemGroup(int p_i1853_1_, String p_i1853_2_) {
     super(p_i1853_1_, p_i1853_2_);
   }
 
   
   public ItemStack createIcon() {
     return new ItemStack((IItemProvider)ItemInit.LEGEND_CRYSTAL.get());
   }
 }




 
 