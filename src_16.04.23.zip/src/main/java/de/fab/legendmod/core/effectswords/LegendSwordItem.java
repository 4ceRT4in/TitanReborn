 package de.fab.legendmod.core.effectswords;
 
 import net.minecraft.item.IItemTier;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 import net.minecraft.item.SwordItem;
 
 public class LegendSwordItem
   extends SwordItem
 {
   public LegendSwordItem(IItemTier p_i48460_1_, int p_i48460_2_, float p_i48460_3_, Item.Properties p_i48460_4_) {
     super(p_i48460_1_, p_i48460_2_, p_i48460_3_, p_i48460_4_);
   }
 
   
   public boolean func_77645_m() {
     return false;
   }
 
   
   public boolean func_77616_k(ItemStack p_77616_1_) {
     return true;
   }
 }





