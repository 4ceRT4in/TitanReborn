    package de.fab.legendmod.core.custombows;
    import net.minecraft.item.ArrowItem;
    import net.minecraft.item.Item;

    public class EffectArrowItem extends ArrowItem {
      public EffectArrowItem(Item.Properties p_i48531_1_) {
     super(p_i48531_1_);
      }
    }





