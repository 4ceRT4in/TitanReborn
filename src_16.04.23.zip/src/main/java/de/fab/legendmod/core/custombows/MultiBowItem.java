 package de.fab.legendmod.core.custombows;
 import net.minecraft.enchantment.EnchantmentHelper;
 import net.minecraft.enchantment.Enchantments;
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.LivingEntity;
 import net.minecraft.entity.player.PlayerEntity;
 import net.minecraft.entity.projectile.AbstractArrowEntity;
 import net.minecraft.entity.projectile.ArrowEntity;
 import net.minecraft.item.ArrowItem;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 import net.minecraft.item.Items;
 import net.minecraft.stats.Stats;
 import net.minecraft.util.Hand;
 import net.minecraft.util.IItemProvider;
 import net.minecraft.util.SoundCategory;
 import net.minecraft.util.SoundEvents;
 import net.minecraft.world.World;
 import net.minecraftforge.event.ForgeEventFactory;
 
 public class MultiBowItem extends LegendBowItem {

     public int maxArrows;
   public MultiBowItem(Item.Properties p_i48522_1_, final int maxArrows) {
     super(p_i48522_1_);
        this.maxArrows = maxArrows;
   }

     public boolean isArrow(ItemStack stack)
     {
         return stack != null && (stack.getItem() instanceof ArrowItem);
     }
     public int getArrowCount(PlayerEntity player, int max) {
         int count = 0;

         if (isArrow(player.getHeldItem(Hand.OFF_HAND))) {
             count += player.getHeldItem(Hand.OFF_HAND).getCount();
         }

         if (isArrow(player.getHeldItem(Hand.MAIN_HAND))) {
             count += player.getHeldItem(Hand.MAIN_HAND).getCount();

         } else {
             for (int i = 0; (i < player.inventory.getSizeInventory()) && (count < max); i++) {
                 ItemStack itemstack = player.inventory.getStackInSlot(i);

                 if (isArrow(itemstack)) {
                     count += itemstack.getCount();
                 }
             }
         }

         return Math.min(count, max);
     }

     public boolean isNormalArrow(ItemStack itemStack) {
         return itemStack.getItem() instanceof ArrowItem;
     }

     public boolean isTitanArrow(ItemStack itemStack) {
         return itemStack.getItem() instanceof EffectArrowItem;
     }

     public ItemStack findAmmo_(PlayerEntity player) {
         if (isArrow(player.getHeldItem(Hand.OFF_HAND))) {
             return player.getHeldItem(Hand.OFF_HAND);
         }
         if (isArrow(player.getHeldItem(Hand.MAIN_HAND))) {
             return player.getHeldItem(Hand.MAIN_HAND);
         }

         for (int i = 0; i < player.inventory.getSizeInventory(); i++) {
             ItemStack itemstack = player.inventory.getStackInSlot(i);

             if (isArrow(itemstack)) {
                 return itemstack;
             }
         }

         return null;
     }

   public void onPlayerStoppedUsing(ItemStack bowStack, World worldIn, LivingEntity entityLiving, int timeLeft) {
       if ((entityLiving instanceof PlayerEntity)) {
           PlayerEntity player = (PlayerEntity) entityLiving;
           int count = getArrowCount(player, this.maxArrows);

           for (int i = 0; i < count; i++) {
               shootArrow(bowStack, worldIn, entityLiving, timeLeft, shootPitchCalc(5.0D, count, i));
           }
       }
   }

     public double shootPitchCalc(double shootPitch, int count, int current) {
         if ((count % 2 != 0) && (current == 0)) {
             return 0.0D;
         }

         int factor;

         if (current % 2 == 0) {
             factor = 1;
         } else {
             factor = -1;
         }

         double part = shootPitch / count;

         return (current / 2 + 1) * factor * part;
     }

     public void shootArrow(ItemStack stack, World worldIn, LivingEntity entityLiving, int timeLeft,
                            double pitchChange) {
         if ((entityLiving instanceof PlayerEntity)) {
             PlayerEntity PlayerEntity = (PlayerEntity) entityLiving;
             boolean flag = (PlayerEntity.abilities.isCreativeMode)
                     || (EnchantmentHelper.getEnchantmentLevel(Enchantments.INFINITY, stack) > 0);
             ItemStack itemstack = findAmmo_(PlayerEntity);

             int maxDuration = getUseDuration(stack);



             int i = maxDuration - timeLeft;

             i /= 2;

             float r = 0F;

             i *= 2.5 - (0.5 * maxArrows);

             i += (i / 4) + ((i / 4)* r);



             i = ForgeEventFactory.onArrowLoose(stack, worldIn, (PlayerEntity) entityLiving, i,
                     (itemstack != null) || (flag));
             if (i < 0) {
                 return;
             }
             if ((itemstack != null) || (flag)) {
                 if (itemstack == null) {
                     itemstack = new ItemStack(Items.ARROW, 64);
                 }

                 float f = getArrowVelocity(i);

                 //f = (f / (1 + (maxArrows - (0.5f * (maxArrows - 1)))));

                 if (f >= 0.1D) {
                     boolean flag1 = (PlayerEntity.abilities.isCreativeMode)
                             || (((itemstack.getItem() instanceof ArrowItem))
                             && (((ArrowItem) itemstack.getItem()).isInfinite(itemstack, stack,
                             PlayerEntity)));

                     if (!worldIn.isRemote) {
                         AbstractArrowEntity entityarrow = null;
                         if(isNormalArrow(itemstack)) {

                             entityarrow = createArrow(worldIn, itemstack, PlayerEntity);

                             entityarrow = customArrow(entityarrow);

                             ArrowItem itemarrow = (ArrowItem) ((itemstack.getItem() instanceof ArrowItem)
                                     ? itemstack.getItem()
                                     : Items.ARROW);
                             entityarrow = itemarrow.createArrow(worldIn, itemstack, PlayerEntity);
                         }
                         if(entityarrow != null) {
                             entityarrow.setDirectionAndMovement(PlayerEntity, PlayerEntity.rotationPitch, PlayerEntity.rotationYaw, 0.0F, Math.min(f * 3.0F, 3.0F), 1.0F);

                             entityarrow.addTag("titan_multi_arrow_tag");

                             //entityarrow.getMo /= Math.min(f * 3.0F, 3.0F);

                             //entityarrow.motionY *= (f * 3);

                             if (f == 1.0F) {
                                 entityarrow.setIsCritical(true);
                             }

                             int j = EnchantmentHelper.getEnchantmentLevel(Enchantments.POWER, stack);

                             if (j > 0) {
                                 entityarrow.setDamage(entityarrow.getDamage() + j * 0.5D + 0.5D);
                             }

                             int k = EnchantmentHelper.getEnchantmentLevel(Enchantments.PUNCH, stack);

                             if (k > 0) {
                                 entityarrow.setKnockbackStrength(k);
                             }

                             if (EnchantmentHelper.getEnchantmentLevel(Enchantments.FLAME, stack) > 0) {
                                 entityarrow.setFire(100);
                             }

                             stack.damageItem(1, (LivingEntity)PlayerEntity, p_220009_1_ -> p_220009_1_.sendBreakAnimation(PlayerEntity.getActiveHand()));


                             if (flag1) {
                                 entityarrow.pickupStatus = AbstractArrowEntity.PickupStatus.CREATIVE_ONLY;
                             }

                             worldIn.addEntity((Entity)entityarrow);

                         }


                     }

                     worldIn.playSound((PlayerEntity)null, PlayerEntity.getPosX(), PlayerEntity.getPosY(), PlayerEntity.getPosZ(), SoundEvents.ENTITY_ARROW_SHOOT, SoundCategory.PLAYERS, 1.0F, 1.0F / (random.nextFloat() * 0.4F + 1.2F) + f * 0.5F);

                     if (!flag1) {
                         itemstack.setCount(itemstack.getCount() - 1);

                         if (itemstack.getCount() == 0) {
                             PlayerEntity.inventory.deleteStack(itemstack);
                         }
                     }

                     PlayerEntity.addStat(Stats.ITEM_USED.get(this));
                 }
             }
         }
     }
   
 }




 
 