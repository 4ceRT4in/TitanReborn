 package de.fab.legendmod.core.init;
 
 import de.fab.legendmod.core.Ores.CitrinOre;
 import de.fab.legendmod.core.Ores.LegendOre;
 import de.fab.legendmod.core.Ores.NetherOre;
 import net.minecraft.block.AbstractBlock;
 import net.minecraft.block.Block;
 import net.minecraft.block.SoundType;
 import net.minecraft.block.material.Material;
 import net.minecraft.block.material.MaterialColor;
 import net.minecraftforge.common.ToolType;
 import net.minecraftforge.fml.RegistryObject;
 import net.minecraftforge.registries.DeferredRegister;
 import net.minecraftforge.registries.ForgeRegistries;
 
 
 
 public class BlockInit
 {
   public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, "legendmod");

   public static final RegistryObject<Block> CITRIN_ORE = BLOCKS.register("citrin_ore", () -> new CitrinOre(AbstractBlock.Properties.create(Material.IRON, MaterialColor.GRAY).hardnessAndResistance(4.5F, 5.0F).harvestTool(ToolType.PICKAXE).harvestLevel(2).sound(SoundType.STONE).setRequiresTool()));
 
 
 
   
   public static final RegistryObject<Block> LEGEND_ORE = BLOCKS.register("legend_ore", () -> new LegendOre(AbstractBlock.Properties.create(Material.IRON, MaterialColor.GRAY).hardnessAndResistance(10.0F, 7.0F).harvestTool(ToolType.PICKAXE).harvestLevel(2).sound(SoundType.STONE).setRequiresTool()));
 
 
 
   
   public static final RegistryObject<Block> NETHER_ORE = BLOCKS.register("nether_ore", () -> new NetherOre(AbstractBlock.Properties.create(Material.IRON, MaterialColor.GRAY).hardnessAndResistance(4.5F, 6.0F).harvestTool(ToolType.PICKAXE).harvestLevel(2).sound(SoundType.NETHERRACK).setRequiresTool()));




     public static final RegistryObject<Block> LEGEND_BLOCK = BLOCKS.register("legend_block", () -> new Block(AbstractBlock.Properties.create(Material.IRON, MaterialColor.PURPLE).hardnessAndResistance(12.0F, 6.0F).harvestTool(ToolType.PICKAXE).harvestLevel(2).sound(SoundType.METAL).setRequiresTool()));
     public static final RegistryObject<Block> CITRIN_BLOCK = BLOCKS.register("citrin_block", () -> new Block(AbstractBlock.Properties.create(Material.IRON, MaterialColor.YELLOW).hardnessAndResistance(12.0F, 6.0F).harvestTool(ToolType.PICKAXE).harvestLevel(2).sound(SoundType.METAL).setRequiresTool()));
     public static final RegistryObject<Block> NETHER_BLOCK = BLOCKS.register("nether_block", () -> new Block(AbstractBlock.Properties.create(Material.IRON, MaterialColor.RED).hardnessAndResistance(12.0F, 6.0F).harvestTool(ToolType.PICKAXE).harvestLevel(2).sound(SoundType.METAL).setRequiresTool()));

   public static final RegistryObject<Block> STONE_LIGHT = BLOCKS.register("stone_light", () -> new Block(AbstractBlock.Properties.create(Material.IRON, MaterialColor.GRAY).hardnessAndResistance(1.5F, 6.0F).harvestTool(ToolType.PICKAXE).harvestLevel(0).sound(SoundType.STONE).setLightLevel(value -> {
       return 15;
   })));
 
 
 
   
   public static final RegistryObject<Block> DIRT_LIGHT = BLOCKS.register("dirt_light", () -> new Block(AbstractBlock.Properties.create(Material.IRON, MaterialColor.BROWN).hardnessAndResistance(0.5F, 0.5F).harvestTool(ToolType.SHOVEL).harvestLevel(0).sound(SoundType.GROUND).setLightLevel(value -> {
       return 15;
   })));
 }




 
 