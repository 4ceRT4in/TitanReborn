 package de.fab.legendmod.core.events;

 import de.fab.legendmod.core.init.ItemInit;

 import java.util.List;
 import java.util.Map;
 import java.util.Random;
 import java.util.UUID;
 import java.util.concurrent.ThreadLocalRandom;
 import java.util.function.Function;
 import java.util.stream.Collectors;
 import java.util.stream.StreamSupport;

 import net.minecraft.entity.LivingEntity;
 import net.minecraft.entity.ai.attributes.AttributeModifier;
 import net.minecraft.entity.ai.attributes.Attributes;
 import net.minecraft.entity.player.PlayerEntity;
 import net.minecraft.entity.player.ServerPlayerEntity;
 import net.minecraft.inventory.EquipmentSlotType;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 import net.minecraft.item.Items;
 import net.minecraft.potion.EffectInstance;
 import net.minecraft.potion.Effects;
 import net.minecraft.potion.PotionUtils;
 import net.minecraft.util.DamageSource;
 import net.minecraft.util.ResourceLocation;
 import net.minecraft.util.SoundEvent;
 import net.minecraft.util.SoundEvents;
 import net.minecraftforge.api.distmarker.Dist;
 import net.minecraftforge.event.TickEvent;
 import net.minecraftforge.event.entity.living.*;
 import net.minecraftforge.event.entity.player.PlayerInteractEvent;
 import net.minecraftforge.eventbus.api.Event;
 import net.minecraftforge.eventbus.api.SubscribeEvent;
 import net.minecraftforge.fml.common.Mod;
 import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
 
 
 
 
 
 
 
 @EventBusSubscriber(modid = "legendmod", bus = Mod.EventBusSubscriber.Bus.FORGE, value = {Dist.DEDICATED_SERVER})
 public class ModServerEvent
 {
   @SubscribeEvent
   public static void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
     if (event.getEntityLiving() instanceof ServerPlayerEntity) {
       ServerPlayerEntity player = (ServerPlayerEntity) event.getEntityLiving();
       ItemStack boots = player.getItemStackFromSlot(EquipmentSlotType.FEET);
       ItemStack leggings = player.getItemStackFromSlot(EquipmentSlotType.LEGS);
       ItemStack chestplate = player.getItemStackFromSlot(EquipmentSlotType.CHEST);
       ItemStack helmet = player.getItemStackFromSlot(EquipmentSlotType.HEAD);

       int ProtectionValue = 0;

       if (boots.getItem() == Items.NETHERITE_BOOTS) {
         ProtectionValue++;
       }

       if (leggings.getItem() == Items.NETHERITE_LEGGINGS) {
         ProtectionValue++;
       }

       if (chestplate.getItem() == Items.NETHERITE_CHESTPLATE) {
         ProtectionValue++;
       }

       if (helmet.getItem() == Items.NETHERITE_HELMET) {
         ProtectionValue++;
       }

       if (ProtectionValue == 4) {
         EffectInstance resistanceEffect = new EffectInstance(Effects.RESISTANCE, 40, 0, false, false, false);
         player.addPotionEffect(resistanceEffect);
       }
     }
   }

   @SubscribeEvent
   public static void onFireDamage(LivingAttackEvent event) {
     if (event.getEntityLiving() instanceof ServerPlayerEntity) {
       ServerPlayerEntity player = (ServerPlayerEntity) event.getEntityLiving();
       DamageSource damageSource = event.getSource();
       List<Item> armorInventory = StreamSupport.stream(player.getArmorInventoryList().spliterator(), false).map(ItemStack::getItem).collect(Collectors.toList());


       int netherArmorProtection = 0;
       for (Item armorItem : ItemInit.getNetherArmorItems()) {
         if (armorInventory.contains(armorItem)) {
           netherArmorProtection++;
         }
       }

       int cureArmorProtection = 0;
       for (Item armorItem : ItemInit.getCitrinArmorItems()) {
         if (armorInventory.contains(armorItem)) {
           cureArmorProtection++;
         }
       }

       if (netherArmorProtection > 0 && damageSource.isFireDamage()) {
         if (randomProtectionChance(netherArmorProtection) == 0) {
           event.setCanceled(true);
         }
       }

       if (netherArmorProtection == 4 && damageSource.isFireDamage()) {
         event.setCanceled(true);
       }

       if (netherArmorProtection > 0 && damageSource == DamageSource.ON_FIRE) {
         if (randomProtectionChance(netherArmorProtection) == 0) {
           player.extinguish();
           event.setCanceled(true);
         }
       }

       if (cureArmorProtection > 0 && (damageSource.isMagicDamage() || damageSource == DamageSource.WITHER)) {
         if (randomProtectionChance(cureArmorProtection) == 0) {
           event.setCanceled(true);
         }
       }

       if (cureArmorProtection == 4 && (damageSource.isMagicDamage() || damageSource == DamageSource.WITHER)) {
         event.setCanceled(true);
       }
     }
   }

   private static int randomProtectionChance(int protectionLevel) {
     return ThreadLocalRandom.current().nextInt(protectionLevel + 1);
   }



   @SubscribeEvent
   public static void onGapUse(LivingEntityUseItemEvent.Finish event) {
     LivingEntity player = event.getEntityLiving();
     ItemStack item = event.getItem();
     EffectInstance absorptionEffect = player.getActivePotionEffect(Effects.ABSORPTION);

     if (!player.world.isRemote && item.getItem() == Items.GOLDEN_APPLE && absorptionEffect != null && absorptionEffect.getAmplifier() == 1) {
       int remainingDuration = absorptionEffect.getDuration();
       player.removePotionEffect(Effects.ABSORPTION);
       player.addPotionEffect(new EffectInstance(Effects.ABSORPTION, remainingDuration, 1));
     }
   }





   @SubscribeEvent
   public static void onCitrinStarThrow(PlayerInteractEvent.RightClickItem event) {
     PlayerEntity player = event.getPlayer(); // PlayerInteractEvent.getEntityLiving() returns null if the entity is not a player
     ItemStack star = event.getItemStack(); // Renamed variable to follow Java naming conventions
     SoundEvent soundEvent = SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH; // Use the existing sound event instead of creating a new one

     if (star.getItem() == ItemInit.CITRIN_STAR.get()) {
       player.playSound(soundEvent, 1.0F, 0.4F);
     }
   }


   @SubscribeEvent
   public static void onTitanArmor(LivingEquipmentChangeEvent event) {
     if (!(event.getEntityLiving() instanceof PlayerEntity)) {
       return;
     }

     LivingEntity player = event.getEntityLiving();
     EquipmentSlotType slot = event.getSlot();
     ItemStack from = event.getFrom();
     ItemStack to = event.getTo();

     AttributeModifier BOOT_BOOST = new AttributeModifier(UUID.fromString("a179274f-c93e-4b89-9f09-2900bbfb2d13"), "boots_boost", 1.0D, AttributeModifier.Operation.ADDITION);
     AttributeModifier LEGGINGS_BOOST = new AttributeModifier(UUID.fromString("21e31eac-76a0-40b7-9e0c-782d02557d35"), "leggings_boost", 3.0D, AttributeModifier.Operation.ADDITION);
     AttributeModifier CHEST_BOOST = new AttributeModifier(UUID.fromString("0ef876bd-108a-4fbc-8cd8-d7181125a0bd"), "chest_boost", 4.0D, AttributeModifier.Operation.ADDITION);
     AttributeModifier HELMET_BOOST = new AttributeModifier(UUID.fromString("7a8c4b78-1b0e-4315-b3dd-2c47a3184aa3"), "helmet_boost", 2.0D, AttributeModifier.Operation.ADDITION);

     if (slot == EquipmentSlotType.FEET) {
       if (to.getItem() == ItemInit.LEGEND_BOOTS.get() && from.getItem() != ItemInit.LEGEND_BOOTS.get()) {
         player.getAttribute(Attributes.MAX_HEALTH).applyNonPersistentModifier(BOOT_BOOST);
       } else if (to.getItem() != ItemInit.LEGEND_BOOTS.get() && from.getItem() == ItemInit.LEGEND_BOOTS.get()) {
         player.getAttribute(Attributes.MAX_HEALTH).removeModifier(BOOT_BOOST);
       }
     } else if (slot == EquipmentSlotType.LEGS) {
       if (to.getItem() == ItemInit.LEGEND_LEGGINGS.get() && from.getItem() != ItemInit.LEGEND_LEGGINGS.get()) {
         player.getAttribute(Attributes.MAX_HEALTH).applyNonPersistentModifier(LEGGINGS_BOOST);
       } else if (to.getItem() != ItemInit.LEGEND_LEGGINGS.get() && from.getItem() == ItemInit.LEGEND_LEGGINGS.get()) {
         player.getAttribute(Attributes.MAX_HEALTH).removeModifier(LEGGINGS_BOOST);
       }
     } else if (slot == EquipmentSlotType.CHEST) {
       if (to.getItem() == ItemInit.LEGEND_CHESTPLATE.get() && from.getItem() != ItemInit.LEGEND_CHESTPLATE.get()) {
         player.getAttribute(Attributes.MAX_HEALTH).applyNonPersistentModifier(CHEST_BOOST);
       } else if (to.getItem() != ItemInit.LEGEND_CHESTPLATE.get() && from.getItem() == ItemInit.LEGEND_CHESTPLATE.get()) {
         player.getAttribute(Attributes.MAX_HEALTH).removeModifier(CHEST_BOOST);
       }
     } else if (slot == EquipmentSlotType.HEAD) {
       if (to.getItem() == ItemInit.LEGEND_HELMET.get() && from.getItem() != ItemInit.LEGEND_HELMET.get()) {
         player.getAttribute(Attributes.MAX_HEALTH).applyNonPersistentModifier(HELMET_BOOST);
       } else if (to.getItem() != ItemInit.LEGEND_HELMET.get() && from.getItem() == ItemInit.LEGEND_HELMET.get()) {
         player.getAttribute(Attributes.MAX_HEALTH).removeModifier(HELMET_BOOST);

       }
     }
   }

   @SubscribeEvent
   public static void effectCitrinStar(PotionEvent.PotionExpiryEvent event) {
     LivingEntity player = event.getEntityLiving();
     EffectInstance effect = event.getPotionEffect();

     for(ItemStack curativeItem : effect.getCurativeItems()){
       if(curativeItem.getItem() == Items.POTION){
         if(curativeItem.getTag().getBoolean("isOldEffect")){
           List<EffectInstance> effectList = PotionUtils.getEffectsFromStack(curativeItem);
           if(effectList.size() > 0){
             player.addPotionEffect(effectList.get(0));

           }
         }
       }
     }
   }
   @SubscribeEvent
   public static void effectReduction(PotionEvent.PotionApplicableEvent event) {
     LivingEntity player = event.getEntityLiving();
     EffectInstance effect = event.getPotionEffect();


     int duration = effect.getDuration();
     int level = effect.getAmplifier();

     int reductionValue = 0;

     ItemStack boots = player.getItemStackFromSlot(EquipmentSlotType.FEET);
     ItemStack leggings = player.getItemStackFromSlot(EquipmentSlotType.LEGS);
     ItemStack chestplate = player.getItemStackFromSlot(EquipmentSlotType.CHEST);
     ItemStack helmet = player.getItemStackFromSlot(EquipmentSlotType.HEAD);

     if (boots.getItem() == ItemInit.CITRIN_BOOTS.get()) {
       reductionValue++;
     }

     if (leggings.getItem() == ItemInit.CITRIN_LEGGINGS.get()) {
       reductionValue++;
     }

     if (chestplate.getItem() == ItemInit.CITRIN_CHESTPLATE.get()) {
       reductionValue++;
     }

     if (helmet.getItem() == ItemInit.CITRIN_HELMET.get()) {
       reductionValue++;
     }

     if (reductionValue > 0 && !player.getTags().contains("reducedPotionEffect") && !effect.getPotion().isBeneficial()) {
       event.setResult(Event.Result.DENY);
       if(reductionValue < 4){
         double[] results = {0.8666025, 0.707106, 0.5};
         int newDuration = (int) (duration * results[reductionValue]);
         player.addTag("reducedPotionEffect");
         player.addPotionEffect(new EffectInstance(effect.getPotion(), newDuration, level));
       }
     }
     if(player.getTags().contains("reducedPotionEffect")){
       player.removeTag("reducedPotionEffect");
     }
   }
 }




 
 