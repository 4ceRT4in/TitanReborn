 package de.fab.legendmod.core.entities.projectiles;
 
 import net.minecraft.entity.LivingEntity;
 import net.minecraft.entity.projectile.ArrowEntity;
 import net.minecraft.potion.EffectInstance;
 import net.minecraft.potion.Effects;
 import net.minecraft.world.World;
 
 public class BlindnessArrowEntity extends ArrowEntity {
   public BlindnessArrowEntity(World p_i46758_1_, LivingEntity p_i46758_2_) {
     super(p_i46758_1_, p_i46758_2_);
   }
 
   
   protected void arrowHit(LivingEntity living) {
     super.arrowHit(living);
     living.addPotionEffect(new EffectInstance(Effects.BLINDNESS, 100, 1));
   }
 }




 
 