 package de.fab.legendmod.core.custombows;
 
 import de.fab.legendmod.core.entities.projectiles.BlindnessArrowEntity;
 import de.fab.legendmod.core.entities.projectiles.PoisonArrowEntity;
 import de.fab.legendmod.core.entities.projectiles.WeaknessArrowEntity;
 import de.fab.legendmod.core.entities.projectiles.WitherArrowEntity;
 import de.fab.legendmod.core.init.ItemInit;
 import java.util.function.Predicate;
 import net.minecraft.entity.LivingEntity;
 import net.minecraft.entity.player.PlayerEntity;
 import net.minecraft.entity.projectile.AbstractArrowEntity;
 import net.minecraft.entity.projectile.ArrowEntity;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 import net.minecraft.item.Items;
 import net.minecraft.world.World;
 
 public class FinalLegendBow
   extends LegendBowItem {
   int ArrowIndicator;
   
   public FinalLegendBow(Item.Properties p_i48522_1_) {
     super(p_i48522_1_);
     
     this.ArrowIndicator = 0;
   }
 
 
   
   public Predicate<ItemStack> getInventoryAmmoPredicate() {
     return ammoStack -> {
         if (ammoStack.getItem() == ItemInit.WEAKNESS_ARROW.get()) {
           this.ArrowIndicator = 1;
           return (ammoStack.getItem() == ItemInit.WEAKNESS_ARROW.get());
         } 
         if (ammoStack.getItem() == ItemInit.WITHER_ARROW.get()) {
           this.ArrowIndicator = 2;
           return (ammoStack.getItem() == ItemInit.WITHER_ARROW.get());
         } 
         if (ammoStack.getItem() == ItemInit.POISON_ARROW.get()) {
           this.ArrowIndicator = 3;
           return (ammoStack.getItem() == ItemInit.POISON_ARROW.get());
         } 
         if (ammoStack.getItem() == ItemInit.BLINDNESS_ARROW.get()) {
           this.ArrowIndicator = 4;
           return (ammoStack.getItem() == ItemInit.BLINDNESS_ARROW.get());
         }
         if(ammoStack.getItem() == Items.SPECTRAL_ARROW){
             return (ammoStack.getItem() == Items.SPECTRAL_ARROW);
         }
         this.ArrowIndicator = 0;
         return (ammoStack.getItem() == Items.ARROW);
       };
   }
 
 
 
 
 
 
   
   protected AbstractArrowEntity createArrow(World worldIn, ItemStack ammoStack, PlayerEntity playerentity) {
     if (this.ArrowIndicator == 1) {
       return (AbstractArrowEntity)new WeaknessArrowEntity(worldIn, (LivingEntity)playerentity);
     }
     
     if (this.ArrowIndicator == 2) {
       return (AbstractArrowEntity)new WitherArrowEntity(worldIn, (LivingEntity)playerentity);
     }
     
     if (this.ArrowIndicator == 3) {
       return (AbstractArrowEntity)new PoisonArrowEntity(worldIn, (LivingEntity)playerentity);
     }
     
     if (this.ArrowIndicator == 4) {
       return (AbstractArrowEntity)new BlindnessArrowEntity(worldIn, (LivingEntity)playerentity);
     }
 
 
 
 
 
     
     return (AbstractArrowEntity)new ArrowEntity(worldIn, (LivingEntity)playerentity);
   }
 
 
   
   public boolean func_77645_m() {
     return false;
   }
 
   
   public boolean func_77616_k(ItemStack p_77616_1_) {
     return true;
   }
 }




 
 