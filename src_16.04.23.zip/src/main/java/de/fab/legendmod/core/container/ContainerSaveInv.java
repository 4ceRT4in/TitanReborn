package de.fab.legendmod.core.container;

import de.fab.legendmod.core.init.ContainerTypesInit;
import de.fab.legendmod.core.inventory.InventorySaveInv;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.container.Container;
import net.minecraft.inventory.container.ContainerType;
import net.minecraft.inventory.container.Slot;
import net.minecraft.network.PacketBuffer;

import javax.annotation.Nullable;

public class ContainerSaveInv extends Container {

    private InventorySaveInv saveInv;

    public ContainerSaveInv(int windowId, PlayerInventory inv, PacketBuffer data){
        
    }

    public ContainerSaveInv(int windowId, PlayerInventory inv, InventorySaveInv saveInv, PacketBuffer data){
        super(ContainerTypesInit.SAVE_INV_CONTAINER.get(), windowId);

        this.saveInv = saveInv;

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 4; j++) {
                addSlot(new Slot(saveInv, j + i * 4, 88 + j * 18, 26 + i * 18));
            }
        }

    }


    @Override
    public boolean canInteractWith(PlayerEntity playerIn) {
        return true;
    }
}
