package de.fab.legendmod.core.init;

import de.fab.legendmod.core.container.ContainerSaveInv;
import net.minecraft.inventory.container.ContainerType;
import net.minecraftforge.common.extensions.IForgeContainerType;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ContainerTypesInit {

    public static final DeferredRegister<ContainerType<?>> CONTAINER_TYPES = DeferredRegister.create(ForgeRegistries.CONTAINERS, "legendmod");

    public static final RegistryObject<ContainerType<ContainerSaveInv>> SAVE_INV_CONTAINER = CONTAINER_TYPES.register("save_inv", () -> IForgeContainerType.create(ContainerSaveInv::new));

}
