 package de.fab.legendmod.core.util;
 
 import net.minecraft.item.Item;
 import net.minecraft.tags.ItemTags;
 import net.minecraft.util.ResourceLocation;
 import net.minecraftforge.common.Tags;
 
 
 
 
 
 public class GreatSwordsTag
 {
   public static class Items
   {
     public static final Tags.IOptionalNamedTag<Item> GREATSWORDS = createTag("greatswords");
     public static final Tags.IOptionalNamedTag<Item> DIAMOND_GREATSWORDS = createTag("diamond_greatswords");
     public static final Tags.IOptionalNamedTag<Item> DIAMOND_SWORDS = createTag("diamond_swords");
     public static final Tags.IOptionalNamedTag<Item> DIAMOND_FURNACE_RECIPE_INGREDIENT = createTag("diamond_furnace_recipe_ingredient");
     public static final Tags.IOptionalNamedTag<Item> DIAMOND_FURNACE_FUEL = createTag("diamond_furnace_fuel");
     
     private static Tags.IOptionalNamedTag<Item> createTag(String name) {
       return ItemTags.createOptional(new ResourceLocation("legendmod", name));
     }
     
     private static Tags.IOptionalNamedTag<Item> createForgeTag(String name) {
       return ItemTags.createOptional(new ResourceLocation("forge", name));
     }
   }
 }




 
 