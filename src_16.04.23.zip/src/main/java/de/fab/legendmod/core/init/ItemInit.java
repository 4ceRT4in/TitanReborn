 package de.fab.legendmod.core.init;
 import de.fab.legendmod.common.material.CustomArmorMaterial;
 import de.fab.legendmod.common.material.CustomToolMaterial;
 import de.fab.legendmod.core.custombows.FinalLegendBow;
 import de.fab.legendmod.core.custombows.MultiBowItem;
 import de.fab.legendmod.core.custombows.citrinstar.CitrinStarItem;
 import de.fab.legendmod.core.custombows.multibow.LegendArrows.*;
 import de.fab.legendmod.core.customshields.DiamondShieldItem;
 import de.fab.legendmod.core.effectarmor.*;
 import de.fab.legendmod.core.effectessence.*;
 import de.fab.legendmod.core.effectswords.Citrin.*;
 import de.fab.legendmod.core.effectswords.CitrinSwordItem;
 import de.fab.legendmod.core.effectswords.Legend.*;
 import de.fab.legendmod.core.effectswords.LegendSwordItem;
 import de.fab.legendmod.core.effectswords.Nether.*;
 import de.fab.legendmod.core.effectswords.NetherSwordItem;
 import de.fab.legendmod.core.effectswords.diamond.*;
 import de.fab.legendmod.core.itemgroup.LegendModItemGroup;
 import net.minecraft.inventory.EquipmentSlotType;
 import net.minecraft.item.*;
 import net.minecraft.potion.EffectInstance;
 import net.minecraft.potion.Effects;
 import net.minecraftforge.fml.RegistryObject;
 import net.minecraftforge.registries.DeferredRegister;
 import net.minecraftforge.registries.ForgeRegistries;

 import java.util.ArrayList;
 import java.util.List;
 import java.util.function.Predicate;

 public class ItemInit {
   public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, "legendmod");
   
   public static final RegistryObject<Item> CITRIN_INGOT = ITEMS.register("citrin_ingot", () -> new Item((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> LEGEND_INGOT = ITEMS.register("legend_ingot", () -> new Item((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> NETHER_INGOT = ITEMS.register("nether_ingot", () -> new Item((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> LEGEND_POWDER = ITEMS.register("legend_powder", () -> new Item((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> NETHER_SHARD = ITEMS.register("nether_shard", () -> new Item((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> PARACHUTE = ITEMS.register("parachute", () -> new Item((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> DIAMOND_APPLE = ITEMS.register("diamond_apple", () -> new Item((new Item.Properties()).food((new Food.Builder()).hunger(4).setAlwaysEdible().saturation(10.0F).effect(new EffectInstance(Effects.REGENERATION, 100, 2), 1.0F).effect(new EffectInstance(Effects.ABSORPTION, 1200, 1), 1.0F).build()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
 
 
   
   public static final RegistryObject<Item> LEGEND_CRYSTAL = ITEMS.register("legend_crystal", () -> new Item((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> SWORD_HANDLE = ITEMS.register("sword_handle", () -> new Item((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD).maxStackSize(1)));
 
 
 
 
   
   public static final RegistryObject<Item> CITRIN_SWORD = ITEMS.register("citrin_sword", () -> new CitrinSwordItem((IItemTier)CustomToolMaterial.CITRIN, 5, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> NETHER_SWORD = ITEMS.register("nether_sword", () -> new NetherSwordItem((IItemTier)CustomToolMaterial.NETHER, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> LEGEND_SWORD = ITEMS.register("legend_sword", () -> new LegendSwordItem((IItemTier)CustomToolMaterial.LEGEND, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
 
 
   
   public static final RegistryObject<Item> CITRIN_GREATSWORD = ITEMS.register("citrin_greatsword", () -> new CitrinSwordItem((IItemTier)CustomToolMaterial.CITRIN_GREAT, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> NETHER_GREATSWORD = ITEMS.register("nether_greatsword", () -> new NetherSwordItem((IItemTier)CustomToolMaterial.NETHER_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> DIAMOND_GREATSWORD = ITEMS.register("diamond_greatsword", () -> new SwordItem((IItemTier)CustomToolMaterial.DIAMOND_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> NETHERITE_GREATSWORD = ITEMS.register("netherite_greatsword", () -> new SwordItem((IItemTier)CustomToolMaterial.NETHERITE_GREAT, 9, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD).isImmuneToFire()));
 
   
   public static final RegistryObject<Item> LEGEND_GREATSWORD = ITEMS.register("legend_greatsword", () -> new LegendSwordItem((IItemTier)CustomToolMaterial.LEGEND_GREAT, 8, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> LEGEND_BOW = ITEMS.register("legend_bow", () -> new FinalLegendBow((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD).maxStackSize(1).maxDamage(9999999)));
 
   
   public static final RegistryObject<Item> WEAKNESS_ARROW = ITEMS.register("weakness_arrow", () -> new WeaknessArrowItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD).maxStackSize(16)));
 
   
   public static final RegistryObject<Item> POISON_ARROW = ITEMS.register("poison_arrow", () -> new PoisonArrowItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD).maxStackSize(16)));
 
   
   public static final RegistryObject<Item> WITHER_ARROW = ITEMS.register("wither_arrow", () -> new WitherArrowItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD).maxStackSize(16)));
 
   
   public static final RegistryObject<Item> BLINDNESS_ARROW = ITEMS.register("blindness_arrow", () -> new BlindnessArrowItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD).maxStackSize(16)));
 
   
   public static final RegistryObject<Item> MULTI_BOW_1 = ITEMS.register("multi_bow_1", () -> new MultiBowItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD).maxStackSize(1).maxDamage(700), 1));
 
   
   public static final RegistryObject<Item> MULTI_BOW_2 = ITEMS.register("multi_bow_2", () -> new MultiBowItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD).maxStackSize(1).maxDamage(1400), 2));
 
   
   public static final RegistryObject<Item> MULTI_BOW_3 = ITEMS.register("multi_bow_3", () -> new MultiBowItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD).maxStackSize(1).maxDamage(2100), 3));
 
 
   
   public static final RegistryObject<Item> CITRIN_BOOTS = ITEMS.register("citrin_boots", () -> new CitrinArmorItem((IArmorMaterial)CustomArmorMaterial.CITRIN_ARMOR, EquipmentSlotType.FEET, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> CITRIN_LEGGINGS = ITEMS.register("citrin_leggings", () -> new CitrinArmorItem((IArmorMaterial)CustomArmorMaterial.CITRIN_ARMOR, EquipmentSlotType.LEGS, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> CITRIN_CHESTPLATE = ITEMS.register("citrin_chestplate", () -> new CitrinArmorItem((IArmorMaterial)CustomArmorMaterial.CITRIN_ARMOR, EquipmentSlotType.CHEST, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> CITRIN_HELMET = ITEMS.register("citrin_helmet", () -> new CitrinArmorItem((IArmorMaterial)CustomArmorMaterial.CITRIN_ARMOR, EquipmentSlotType.HEAD, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> NETHER_BOOTS = ITEMS.register("nether_boots", () -> new NetherArmorItem((IArmorMaterial)CustomArmorMaterial.NETHER_ARMOR, EquipmentSlotType.FEET, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> NETHER_LEGGINGS = ITEMS.register("nether_leggings", () -> new NetherArmorItem((IArmorMaterial)CustomArmorMaterial.NETHER_ARMOR, EquipmentSlotType.LEGS, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> NETHER_CHESTPLATE = ITEMS.register("nether_chestplate", () -> new NetherArmorItem((IArmorMaterial)CustomArmorMaterial.NETHER_ARMOR, EquipmentSlotType.CHEST, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> NETHER_HELMET = ITEMS.register("nether_helmet", () -> new NetherArmorItem((IArmorMaterial)CustomArmorMaterial.NETHER_ARMOR, EquipmentSlotType.HEAD, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> LEGEND_BOOTS = ITEMS.register("legend_boots", () -> new LegendBootsItem((IArmorMaterial)CustomArmorMaterial.LEGEND_ARMOR, EquipmentSlotType.FEET, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> LEGEND_LEGGINGS = ITEMS.register("legend_leggings", () -> new LegendLeggingsItem((IArmorMaterial)CustomArmorMaterial.LEGEND_ARMOR, EquipmentSlotType.LEGS, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> LEGEND_CHESTPLATE = ITEMS.register("legend_chestplate", () -> new LegendChestplateItem((IArmorMaterial)CustomArmorMaterial.LEGEND_ARMOR, EquipmentSlotType.CHEST, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> LEGEND_HELMET = ITEMS.register("legend_helmet", () -> new LegendHelmetItem((IArmorMaterial)CustomArmorMaterial.LEGEND_ARMOR, EquipmentSlotType.HEAD, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> CITRIN_STAR = ITEMS.register("citrin_star", () -> new CitrinStarItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD).maxStackSize(16)));
 
   
   public static final RegistryObject<Item> DIAMOND_SHIELD = ITEMS.register("diamond_shield", () -> new DiamondShieldItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD).maxStackSize(1).defaultMaxDamage(1685)));
 
   
   public static final RegistryObject<Item> LEGEND_SHIELD = ITEMS.register("legend_shield", () -> new ShieldItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD).maxStackSize(1)));
 
   
   public static final RegistryObject<Item> LEGEND_SLINGSHOT = ITEMS.register("legend_slingshot", () -> new ShootableItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD).maxStackSize(1))
       {
         public Predicate<ItemStack> getInventoryAmmoPredicate()
         {
           return null;
         }
 
         
         public int func_230305_d_() {
           return 0;
         }
       });
 

 
 
   
   public static final RegistryObject<Item> BLIND1_CITRIN_SWORD = ITEMS.register("blind1_citrin_sword", () -> new Citrin1Blind((IItemTier)CustomToolMaterial.CITRIN, 5, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> BLIND2_CITRIN_SWORD = ITEMS.register("blind2_citrin_sword", () -> new Citrin2Blind((IItemTier)CustomToolMaterial.CITRIN, 5, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> FIRE1_CITRIN_SWORD = ITEMS.register("fire1_citrin_sword", () -> new Citrin1Fire((IItemTier)CustomToolMaterial.CITRIN, 5, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> FIRE2_CITRIN_SWORD = ITEMS.register("fire2_citrin_sword", () -> new Citrin2Fire((IItemTier)CustomToolMaterial.CITRIN, 5, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> POISON1_CITRIN_SWORD = ITEMS.register("poison1_citrin_sword", () -> new Citrin1Poison((IItemTier)CustomToolMaterial.CITRIN, 5, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> POISON2_CITRIN_SWORD = ITEMS.register("poison2_citrin_sword", () -> new Citrin2Poison((IItemTier)CustomToolMaterial.CITRIN, 5, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WEAK1_CITRIN_SWORD = ITEMS.register("weak1_citrin_sword", () -> new Citrin1Weak((IItemTier)CustomToolMaterial.CITRIN, 5, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WEAK2_CITRIN_SWORD = ITEMS.register("weak2_citrin_sword", () -> new Citrin2Weak((IItemTier)CustomToolMaterial.CITRIN, 5, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WITHER1_CITRIN_SWORD = ITEMS.register("wither1_citrin_sword", () -> new Citrin1Wither((IItemTier)CustomToolMaterial.CITRIN, 5, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WITHER2_CITRIN_SWORD = ITEMS.register("wither2_citrin_sword", () -> new Citrin2Wither((IItemTier)CustomToolMaterial.CITRIN, 5, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
 
   
   public static final RegistryObject<Item> BLIND1_NETHER_SWORD = ITEMS.register("blind1_nether_sword", () -> new Nether1Blind((IItemTier)CustomToolMaterial.NETHER, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> BLIND2_NETHER_SWORD = ITEMS.register("blind2_nether_sword", () -> new Nether2Blind((IItemTier)CustomToolMaterial.NETHER, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> FIRE1_NETHER_SWORD = ITEMS.register("fire1_nether_sword", () -> new Nether1Fire((IItemTier)CustomToolMaterial.NETHER, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> FIRE2_NETHER_SWORD = ITEMS.register("fire2_nether_sword", () -> new Nether2Fire((IItemTier)CustomToolMaterial.NETHER, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> POISON1_NETHER_SWORD = ITEMS.register("poison1_nether_sword", () -> new Nether1Poison((IItemTier)CustomToolMaterial.NETHER, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> POISON2_NETHER_SWORD = ITEMS.register("poison2_nether_sword", () -> new Nether2Poison((IItemTier)CustomToolMaterial.NETHER, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WEAK1_NETHER_SWORD = ITEMS.register("weak1_nether_sword", () -> new Nether1Weak((IItemTier)CustomToolMaterial.NETHER, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WEAK2_NETHER_SWORD = ITEMS.register("weak2_nether_sword", () -> new Nether2Weak((IItemTier)CustomToolMaterial.NETHER, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WITHER1_NETHER_SWORD = ITEMS.register("wither1_nether_sword", () -> new Nether1Wither((IItemTier)CustomToolMaterial.NETHER, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WITHER2_NETHER_SWORD = ITEMS.register("wither2_nether_sword", () -> new Nether2Wither((IItemTier)CustomToolMaterial.NETHER, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
 
   
   public static final RegistryObject<Item> BLIND1_LEGEND_SWORD = ITEMS.register("blind1_legend_sword", () -> new Legend1Blind((IItemTier)CustomToolMaterial.LEGEND, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> BLIND2_LEGEND_SWORD = ITEMS.register("blind2_legend_sword", () -> new Legend2Blind((IItemTier)CustomToolMaterial.LEGEND, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> FIRE1_LEGEND_SWORD = ITEMS.register("fire1_legend_sword", () -> new Legend1Fire((IItemTier)CustomToolMaterial.LEGEND, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> FIRE2_LEGEND_SWORD = ITEMS.register("fire2_legend_sword", () -> new Legend2Fire((IItemTier)CustomToolMaterial.LEGEND, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> POISON1_LEGEND_SWORD = ITEMS.register("poison1_legend_sword", () -> new Legend1Poison((IItemTier)CustomToolMaterial.LEGEND, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> POISON2_LEGEND_SWORD = ITEMS.register("poison2_legend_sword", () -> new Legend2Poison((IItemTier)CustomToolMaterial.LEGEND, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WEAK1_LEGEND_SWORD = ITEMS.register("weak1_legend_sword", () -> new Legend1Weak((IItemTier)CustomToolMaterial.LEGEND, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WEAK2_LEGEND_SWORD = ITEMS.register("weak2_legend_sword", () -> new Legend2Weak((IItemTier)CustomToolMaterial.LEGEND, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WITHER1_LEGEND_SWORD = ITEMS.register("wither1_legend_sword", () -> new Legend1Wither((IItemTier)CustomToolMaterial.LEGEND, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WITHER2_LEGEND_SWORD = ITEMS.register("wither2_legend_sword", () -> new Legend2Wither((IItemTier)CustomToolMaterial.LEGEND, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
 
 
   
   public static final RegistryObject<Item> BLIND1_DIAMOND_SWORD = ITEMS.register("blind1_diamond_sword", () -> new Diamond1Blind((IItemTier)CustomToolMaterial.DIAMOND, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> BLIND2_DIAMOND_SWORD = ITEMS.register("blind2_diamond_sword", () -> new Diamond2Blind((IItemTier)CustomToolMaterial.DIAMOND, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> FIRE1_DIAMOND_SWORD = ITEMS.register("fire1_diamond_sword", () -> new Diamond1Fire((IItemTier)CustomToolMaterial.DIAMOND, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> FIRE2_DIAMOND_SWORD = ITEMS.register("fire2_diamond_sword", () -> new Diamond2Fire((IItemTier)CustomToolMaterial.DIAMOND, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> POISON1_DIAMOND_SWORD = ITEMS.register("poison1_diamond_sword", () -> new Diamond1Poison((IItemTier)CustomToolMaterial.DIAMOND, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> POISON2_DIAMOND_SWORD = ITEMS.register("poison2_diamond_sword", () -> new Diamond2Poison((IItemTier)CustomToolMaterial.DIAMOND, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WEAK1_DIAMOND_SWORD = ITEMS.register("weak1_diamond_sword", () -> new Diamond1Weak((IItemTier)CustomToolMaterial.DIAMOND, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WEAK2_DIAMOND_SWORD = ITEMS.register("weak2_diamond_sword", () -> new Diamond2Weak((IItemTier)CustomToolMaterial.DIAMOND, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WITHER1_DIAMOND_SWORD = ITEMS.register("wither1_diamond_sword", () -> new Diamond1Wither((IItemTier)CustomToolMaterial.DIAMOND, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WITHER2_DIAMOND_SWORD = ITEMS.register("wither2_diamond_sword", () -> new Diamond2Wither((IItemTier)CustomToolMaterial.DIAMOND, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
 
 
   
   public static final RegistryObject<Item> BLIND1_CITRIN_GREATSWORD = ITEMS.register("blind1_citrin_greatsword", () -> new Citrin1Blind((IItemTier)CustomToolMaterial.CITRIN_GREAT, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> BLIND2_CITRIN_GREATSWORD = ITEMS.register("blind2_citrin_greatsword", () -> new Citrin2Blind((IItemTier)CustomToolMaterial.CITRIN_GREAT, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> FIRE1_CITRIN_GREATSWORD = ITEMS.register("fire1_citrin_greatsword", () -> new Citrin1Fire((IItemTier)CustomToolMaterial.CITRIN_GREAT, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> FIRE2_CITRIN_GREATSWORD = ITEMS.register("fire2_citrin_greatsword", () -> new Citrin2Fire((IItemTier)CustomToolMaterial.CITRIN_GREAT, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> POISON1_CITRIN_GREATSWORD = ITEMS.register("poison1_citrin_greatsword", () -> new Citrin1Poison((IItemTier)CustomToolMaterial.CITRIN_GREAT, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> POISON2_CITRIN_GREATSWORD = ITEMS.register("poison2_citrin_greatsword", () -> new Citrin2Poison((IItemTier)CustomToolMaterial.CITRIN_GREAT, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WEAK1_CITRIN_GREATSWORD = ITEMS.register("weak1_citrin_greatsword", () -> new Citrin1Weak((IItemTier)CustomToolMaterial.CITRIN_GREAT, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WEAK2_CITRIN_GREATSWORD = ITEMS.register("weak2_citrin_greatsword", () -> new Citrin2Weak((IItemTier)CustomToolMaterial.CITRIN_GREAT, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WITHER1_CITRIN_GREATSWORD = ITEMS.register("wither1_citrin_greatsword", () -> new Citrin1Wither((IItemTier)CustomToolMaterial.CITRIN_GREAT, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WITHER2_CITRIN_GREATSWORD = ITEMS.register("wither2_citrin_greatsword", () -> new Citrin2Wither((IItemTier)CustomToolMaterial.CITRIN_GREAT, 6, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
 
 
   
   public static final RegistryObject<Item> BLIND1_NETHER_GREATSWORD = ITEMS.register("blind1_nether_greatsword", () -> new Nether1Blind((IItemTier)CustomToolMaterial.NETHER_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> BLIND2_NETHER_GREATSWORD = ITEMS.register("blind2_nether_greatsword", () -> new Nether2Blind((IItemTier)CustomToolMaterial.NETHER_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> FIRE1_NETHER_GREATSWORD = ITEMS.register("fire1_nether_greatsword", () -> new Nether1Fire((IItemTier)CustomToolMaterial.NETHER_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> FIRE2_NETHER_GREATSWORD = ITEMS.register("fire2_nether_greatsword", () -> new Nether2Fire((IItemTier)CustomToolMaterial.NETHER_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> POISON1_NETHER_GREATSWORD = ITEMS.register("poison1_nether_greatsword", () -> new Nether1Poison((IItemTier)CustomToolMaterial.NETHER_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> POISON2_NETHER_GREATSWORD = ITEMS.register("poison2_nether_greatsword", () -> new Nether2Poison((IItemTier)CustomToolMaterial.NETHER_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WEAK1_NETHER_GREATSWORD = ITEMS.register("weak1_nether_greatsword", () -> new Nether1Weak((IItemTier)CustomToolMaterial.NETHER_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WEAK2_NETHER_GREATSWORD = ITEMS.register("weak2_nether_greatsword", () -> new Nether2Weak((IItemTier)CustomToolMaterial.NETHER_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WITHER1_NETHER_GREATSWORD = ITEMS.register("wither1_nether_greatsword", () -> new Nether1Wither((IItemTier)CustomToolMaterial.NETHER_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WITHER2_NETHER_GREATSWORD = ITEMS.register("wither2_nether_greatsword", () -> new Nether2Wither((IItemTier)CustomToolMaterial.NETHER_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
 
 
   
   public static final RegistryObject<Item> BLIND1_LEGEND_GREATSWORD = ITEMS.register("blind1_legend_greatsword", () -> new Legend1Blind((IItemTier)CustomToolMaterial.LEGEND_GREAT, 8, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> BLIND2_LEGEND_GREATSWORD = ITEMS.register("blind2_legend_greatsword", () -> new Legend2Blind((IItemTier)CustomToolMaterial.LEGEND_GREAT, 8, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> FIRE1_LEGEND_GREATSWORD = ITEMS.register("fire1_legend_greatsword", () -> new Legend1Fire((IItemTier)CustomToolMaterial.LEGEND_GREAT, 8, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> FIRE2_LEGEND_GREATSWORD = ITEMS.register("fire2_legend_greatsword", () -> new Legend2Fire((IItemTier)CustomToolMaterial.LEGEND_GREAT, 8, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> POISON1_LEGEND_GREATSWORD = ITEMS.register("poison1_legend_greatsword", () -> new Legend1Poison((IItemTier)CustomToolMaterial.LEGEND_GREAT, 8, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> POISON2_LEGEND_GREATSWORD = ITEMS.register("poison2_legend_greatsword", () -> new Legend2Poison((IItemTier)CustomToolMaterial.LEGEND_GREAT, 8, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WEAK1_LEGEND_GREATSWORD = ITEMS.register("weak1_legend_greatsword", () -> new Legend1Weak((IItemTier)CustomToolMaterial.LEGEND_GREAT, 8, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WEAK2_LEGEND_GREATSWORD = ITEMS.register("weak2_legend_greatsword", () -> new Legend2Weak((IItemTier)CustomToolMaterial.LEGEND_GREAT, 8, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WITHER1_LEGEND_GREATSWORD = ITEMS.register("wither1_legend_greatsword", () -> new Legend1Wither((IItemTier)CustomToolMaterial.LEGEND_GREAT, 8, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WITHER2_LEGEND_GREATSWORD = ITEMS.register("wither2_legend_greatsword", () -> new Legend2Wither((IItemTier)CustomToolMaterial.LEGEND_GREAT, 8, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
 
 
   
   public static final RegistryObject<Item> BLIND1_DIAMOND_GREATSWORD = ITEMS.register("blind1_diamond_greatsword", () -> new Diamond1Blind((IItemTier)CustomToolMaterial.DIAMOND_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> BLIND2_DIAMOND_GREATSWORD = ITEMS.register("blind2_diamond_greatsword", () -> new Diamond2Blind((IItemTier)CustomToolMaterial.DIAMOND_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> FIRE1_DIAMOND_GREATSWORD = ITEMS.register("fire1_diamond_greatsword", () -> new Diamond1Fire((IItemTier)CustomToolMaterial.DIAMOND_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> FIRE2_DIAMOND_GREATSWORD = ITEMS.register("fire2_diamond_greatsword", () -> new Diamond2Fire((IItemTier)CustomToolMaterial.DIAMOND_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> POISON1_DIAMOND_GREATSWORD = ITEMS.register("poison1_diamond_greatsword", () -> new Diamond1Poison((IItemTier)CustomToolMaterial.DIAMOND_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> POISON2_DIAMOND_GREATSWORD = ITEMS.register("poison2_diamond_greatsword", () -> new Diamond2Poison((IItemTier)CustomToolMaterial.DIAMOND_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WEAK1_DIAMOND_GREATSWORD = ITEMS.register("weak1_diamond_greatsword", () -> new Diamond1Weak((IItemTier)CustomToolMaterial.DIAMOND_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WEAK2_DIAMOND_GREATSWORD = ITEMS.register("weak2_diamond_greatsword", () -> new Diamond2Weak((IItemTier)CustomToolMaterial.DIAMOND_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WITHER1_DIAMOND_GREATSWORD = ITEMS.register("wither1_diamond_greatsword", () -> new Diamond1Wither((IItemTier)CustomToolMaterial.DIAMOND_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
   
   public static final RegistryObject<Item> WITHER2_DIAMOND_GREATSWORD = ITEMS.register("wither2_diamond_greatsword", () -> new Diamond2Wither((IItemTier)CustomToolMaterial.DIAMOND_GREAT, 7, 9996.0F, (new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
 
 
 
 
 
 
   
   public static final RegistryObject<Item> BLINDNESS_ESSENCE = ITEMS.register("blindness_essence", () -> new BlindnessEssenceItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> FIRE_ESSENCE = ITEMS.register("fire_essence", () -> new FireEssenceItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> POISON_ESSENCE = ITEMS.register("poison_essence", () -> new PoisonEssenceItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WEAKNESS_ESSENCE = ITEMS.register("weakness_essence", () -> new WeaknessEssenceItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));
 
   
   public static final RegistryObject<Item> WITHER_ESSENCE = ITEMS.register("wither_essence", () -> new WitherEssenceItem((new Item.Properties()).group((ItemGroup)LegendModItemGroup.LEGEND_MOD)));


   public static List<Item> getNetherArmorItems() {
     List<Item> netherArmorItems = new ArrayList<>();

     // Add each nether armor item to the list
     netherArmorItems.add(ItemInit.NETHER_HELMET.get());
     netherArmorItems.add(ItemInit.NETHER_CHESTPLATE.get());
     netherArmorItems.add(ItemInit.NETHER_LEGGINGS.get());
     netherArmorItems.add(ItemInit.NETHER_BOOTS.get());

     return netherArmorItems;
   }


   public static List<Item> getCitrinArmorItems() {
       List<Item> citrinArmorItems = new ArrayList<>();

       // Add each citrin armor item to the list
     citrinArmorItems.add(ItemInit.CITRIN_HELMET.get());
     citrinArmorItems.add(ItemInit.CITRIN_CHESTPLATE.get());
     citrinArmorItems.add(ItemInit.CITRIN_LEGGINGS.get());
     citrinArmorItems.add(ItemInit.CITRIN_BOOTS.get());

       return citrinArmorItems;
   }
 }




 
 