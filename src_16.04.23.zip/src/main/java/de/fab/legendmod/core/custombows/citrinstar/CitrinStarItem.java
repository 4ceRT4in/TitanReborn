 package de.fab.legendmod.core.custombows.citrinstar;
 
 import net.minecraft.entity.Entity;
 import net.minecraft.entity.LivingEntity;
 import net.minecraft.entity.player.PlayerEntity;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 import net.minecraft.item.ItemUseContext;
 import net.minecraft.stats.Stats;
 import net.minecraft.util.ActionResult;
 import net.minecraft.util.ActionResultType;
 import net.minecraft.util.Hand;
 import net.minecraft.world.World;
 
 
 
 
 public class CitrinStarItem
   extends Item
 {
   public CitrinStarItem(Item.Properties p_i48487_1_) {
     super(p_i48487_1_);
   }


     public ActionResult<ItemStack> onItemRightClick(World worldIn, PlayerEntity playerIn, Hand handIn) {
         playerIn.getCooldownTracker().setCooldown(this, 10);
     ItemStack itemstack = playerIn.getHeldItem(handIn);
     if (!worldIn.isRemote) {
       CitrinStarEntity citrinstarentity = new CitrinStarEntity(worldIn, (LivingEntity)playerIn);
       citrinstarentity.setItem(itemstack);
       citrinstarentity.setDirectionAndMovement(playerIn,playerIn.rotationPitch, playerIn.rotationYaw, -2.0F, 2.0F, 1.0F);
       worldIn.addEntity((Entity)citrinstarentity);
     } 
     
     playerIn.addStat(Stats.ITEM_USED.get(this));
     if (!playerIn.abilities.isCreativeMode) {
       itemstack.shrink(1);
     }
     
     return ActionResult.func_233538_a_(itemstack, worldIn.isRemote());
   }
 }




 
 