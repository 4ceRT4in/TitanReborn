 package de.fab.legendmod.core.events;
 
 import de.fab.legendmod.core.util.GreatSwordsTag;
 import net.minecraft.entity.LivingEntity;
 import net.minecraft.inventory.EquipmentSlotType;
 import net.minecraft.item.ItemStack;
 import net.minecraft.potion.EffectInstance;
 import net.minecraft.potion.Effects;
 import net.minecraft.tags.ITag;
 import net.minecraftforge.api.distmarker.Dist;
 import net.minecraftforge.event.entity.player.AttackEntityEvent;
 import net.minecraftforge.event.entity.player.PlayerInteractEvent;
 import net.minecraftforge.eventbus.api.SubscribeEvent;
 import net.minecraftforge.fml.common.Mod;
 import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
 
 
 
 
 @EventBusSubscriber(modid = "legendmod", bus = Mod.EventBusSubscriber.Bus.FORGE, value = {Dist.CLIENT})
 public class GreatSwordFatigue
 {
   @SubscribeEvent
   public static void onGreatSwordClick(PlayerInteractEvent.LeftClickEmpty event) {
     LivingEntity player = event.getEntityLiving();
     ItemStack GreatSword = event.getItemStack();
     
     ItemStack equipped = player.getItemStackFromSlot(EquipmentSlotType.MAINHAND);
     
     if (equipped.getItem().isIn((ITag)GreatSwordsTag.Items.GREATSWORDS)) {
 
       
       player.addPotionEffect(new EffectInstance(Effects.MINING_FATIGUE, 20, 2, false, false));
     }
     else {
       
       player.removePotionEffect(Effects.MINING_FATIGUE);
     } 
   }
 
 
 
 
 
   
   @SubscribeEvent
   public static void onGreatSwordRightClick(PlayerInteractEvent.RightClickEmpty event) {
     LivingEntity player = event.getEntityLiving();
     ItemStack GreatSword = event.getItemStack();
     
     ItemStack equipped = player.getItemStackFromSlot(EquipmentSlotType.MAINHAND);
     
     if (equipped.getItem().isIn((ITag)GreatSwordsTag.Items.GREATSWORDS)) {
 
       
       player.addPotionEffect(new EffectInstance(Effects.MINING_FATIGUE, 20, 2, false, false));
     }
     else {
       
       player.removePotionEffect(Effects.MINING_FATIGUE);
     } 
   }
 
 
 
 
 
   
   @SubscribeEvent
   public static void onGreatSwordBlockClick(PlayerInteractEvent.LeftClickBlock event) {
     LivingEntity player = event.getEntityLiving();
     ItemStack equipped = player.getItemStackFromSlot(EquipmentSlotType.MAINHAND);
     
     if (equipped.getItem().isIn((ITag)GreatSwordsTag.Items.GREATSWORDS)) {
       
       player.addPotionEffect(new EffectInstance(Effects.MINING_FATIGUE, 20, 2, false, false));
     
     }
     else {
       
       player.removePotionEffect(Effects.MINING_FATIGUE);
     } 
   }
 
   
   @SubscribeEvent
   public static void onGreatSwordBlockRightClick(PlayerInteractEvent.RightClickBlock event) {
     LivingEntity player = event.getEntityLiving();
     ItemStack equipped = player.getItemStackFromSlot(EquipmentSlotType.MAINHAND);
     
     if (equipped.getItem().isIn((ITag)GreatSwordsTag.Items.GREATSWORDS)) {
       
       player.addPotionEffect(new EffectInstance(Effects.MINING_FATIGUE, 20, 2, false, false));
     
     }
     else {
       
       player.removePotionEffect(Effects.MINING_FATIGUE);
     } 
   }
 
   
   @SubscribeEvent
   public static void onGreatSwordTarget(AttackEntityEvent event) {
     LivingEntity player = event.getEntityLiving();
     ItemStack equipped = player.getItemStackFromSlot(EquipmentSlotType.MAINHAND);
     
     if (equipped.getItem().isIn((ITag)GreatSwordsTag.Items.GREATSWORDS)) {
       
       player.addPotionEffect(new EffectInstance(Effects.MINING_FATIGUE, 20, 2, false, false));
     
     }
     else {
       
       player.removePotionEffect(Effects.MINING_FATIGUE);
     } 
   }
 }




 
 