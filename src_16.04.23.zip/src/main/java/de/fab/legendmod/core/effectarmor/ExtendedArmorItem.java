 package de.fab.legendmod.core.effectarmor;
 
 import net.minecraft.inventory.EquipmentSlotType;
 import net.minecraft.item.ArmorItem;
 import net.minecraft.item.IArmorMaterial;
 import net.minecraft.item.Item;
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 public class ExtendedArmorItem
   extends ArmorItem
 {
   public ExtendedArmorItem(IArmorMaterial material, EquipmentSlotType slot, Item.Properties settings) {
     super(material, slot, settings);
   }
 }




 
 