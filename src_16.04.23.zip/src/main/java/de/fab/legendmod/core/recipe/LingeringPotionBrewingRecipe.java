package de.fab.legendmod.core.recipe;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtils;
import net.minecraft.potion.Potions;
import net.minecraftforge.common.brewing.BrewingRecipe;

public class LingeringPotionBrewingRecipe extends BrewingRecipe {
    private Item ingredient;

    public LingeringPotionBrewingRecipe(ItemStack input, ItemStack ingredient, ItemStack output) {
        super(Ingredient.fromStacks(input), Ingredient.fromStacks(ingredient), output);
    }

    @Override
    public boolean isInput(ItemStack stack) {
        // Check that input is a splash potion
        return stack.getItem() == Items.SPLASH_POTION;
    }


    @Override
    public ItemStack getOutput(ItemStack input, ItemStack ingredient) {
        // Check that input is a potion
        if (input.getItem() != Items.SPLASH_POTION) {
            // Input potion is not a splash potion, return empty output
            return ItemStack.EMPTY;
        }

        if (!PotionUtils.getPotionFromItem(input).getEffects().isEmpty()) {
            // Create output potion with same effects as input potion
            ItemStack output = new ItemStack(Items.LINGERING_POTION);
            output = PotionUtils.addPotionToItemStack(output, PotionUtils.getPotionFromItem(input));
            // Copy potion effects from input potion to output potion
            //PotionUtils.getCustomPotionEffects(input).forEach(effect -> PotionUtils.addPotionToItemStack(output, effect));
            return output;
        }
        return ItemStack.EMPTY;
    }

}

