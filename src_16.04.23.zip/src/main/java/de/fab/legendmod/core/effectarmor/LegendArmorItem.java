 package de.fab.legendmod.core.effectarmor;
 
 import net.minecraft.inventory.EquipmentSlotType;
 import net.minecraft.item.IArmorMaterial;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 public class LegendArmorItem
   extends ExtendedArmorItem
 {
   public LegendArmorItem(IArmorMaterial material, EquipmentSlotType slot, Item.Properties settings) {
     super(material, slot, settings);
   }
 
   
   public boolean func_77645_m() {
     return false;
   }
 
   
   public boolean func_77616_k(ItemStack p_77616_1_) {
     return true;
   }
 }




 
 