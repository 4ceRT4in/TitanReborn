 package de.fab.legendmod.core.customshields;
 
 import javax.annotation.Nullable;
 import net.minecraft.entity.LivingEntity;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 import net.minecraft.item.ShieldItem;
 
 
 
 public class DiamondShieldItem
   extends ShieldItem
 {
   public DiamondShieldItem(Item.Properties p_i48470_1_) {
     super(p_i48470_1_);
   }
 
   
   public boolean isShield(ItemStack stack, @Nullable LivingEntity entity) {
     return true;
   }
 
   
   public boolean func_77645_m() {
     return true;
   }
 }




 
 