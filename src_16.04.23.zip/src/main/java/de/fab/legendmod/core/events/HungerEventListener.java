package de.fab.legendmod.core.events;

import net.minecraft.world.GameRules;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class HungerEventListener {


    private static int MIN_HUNGER = 17;
    private static int REGEN_TIME = 80;
    private static float EXHAUSTION = 6.0F;

    @SubscribeEvent
    public void tickPlayer(TickEvent.PlayerTickEvent event) {
        if (event.phase == TickEvent.Phase.START && event.player
                .getHealth() < event.player.getMaxHealth() && event.player
                .getFoodStats().getFoodLevel() >= MIN_HUNGER &&
                event.player.getEntityWorld().getGameTime() % REGEN_TIME == 0L) {
            event.player.heal(1.0F);
            event.player.getFoodStats().addExhaustion(EXHAUSTION);
        }
    }

    @SubscribeEvent
    public void event(WorldEvent.Load event) {
        event.getWorld().getWorldInfo().getGameRulesInstance().get(GameRules.NATURAL_REGENERATION).set(false, null);
    }

}
