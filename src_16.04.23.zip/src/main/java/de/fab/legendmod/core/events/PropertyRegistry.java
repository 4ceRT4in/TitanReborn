package de.fab.legendmod.core.events;

import de.fab.legendmod.core.custombows.MultiBowItem;
import de.fab.legendmod.core.init.ItemInit;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemModelsProperties;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class PropertyRegistry {
    @SubscribeEvent
    public static void propertyOverrideRegistry(FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            ItemModelsProperties.registerProperty(ItemInit.MULTI_BOW_1.get(), new ResourceLocation("legendmod", "maxarrows"), (itemStack, clientWorld, livingEntity) -> {
                return ((MultiBowItem) itemStack.getItem()).maxArrows;
            });
            ItemModelsProperties.registerProperty(ItemInit.MULTI_BOW_1.get(), new ResourceLocation("legendmod", "currentarrows"), (itemStack, clientWorld, livingEntity) -> {
                if ((livingEntity != null) && ((livingEntity instanceof PlayerEntity))) {
                    return ((MultiBowItem) itemStack.getItem()).getArrowCount((PlayerEntity) livingEntity, ((MultiBowItem) itemStack.getItem()).maxArrows);
                }
                return 0.0F;
            });
            ItemModelsProperties.registerProperty(ItemInit.MULTI_BOW_2.get(), new ResourceLocation("legendmod", "maxarrows"), (itemStack, clientWorld, livingEntity) -> {
                return ((MultiBowItem) itemStack.getItem()).maxArrows;
            });
            ItemModelsProperties.registerProperty(ItemInit.MULTI_BOW_2.get(), new ResourceLocation("legendmod", "currentarrows"), (itemStack, clientWorld, livingEntity) -> {
                if ((livingEntity != null) && ((livingEntity instanceof PlayerEntity))) {
                    return ((MultiBowItem) itemStack.getItem()).getArrowCount((PlayerEntity) livingEntity, ((MultiBowItem) itemStack.getItem()).maxArrows);
                }
                return 0.0F;
            });
            ItemModelsProperties.registerProperty(ItemInit.MULTI_BOW_3.get(), new ResourceLocation("legendmod", "maxarrows"), (itemStack, clientWorld, livingEntity) -> {
                return ((MultiBowItem) itemStack.getItem()).maxArrows;
            });
            ItemModelsProperties.registerProperty(ItemInit.MULTI_BOW_3.get(), new ResourceLocation("legendmod", "currentarrows"), (itemStack, clientWorld, livingEntity) -> {
                if ((livingEntity != null) && ((livingEntity instanceof PlayerEntity))) {
                    return ((MultiBowItem) itemStack.getItem()).getArrowCount((PlayerEntity) livingEntity, ((MultiBowItem) itemStack.getItem()).maxArrows);
                }
                return 0.0F;
            });
        });
    }

}
