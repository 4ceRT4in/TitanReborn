 package de.fab.legendmod.core.effectarmor;
 
 import java.util.List;
 import javax.annotation.Nullable;
 import net.minecraft.client.util.ITooltipFlag;
 import net.minecraft.inventory.EquipmentSlotType;
 import net.minecraft.item.IArmorMaterial;
 import net.minecraft.item.Item;
 import net.minecraft.item.ItemStack;
 import net.minecraft.util.text.ITextComponent;
 import net.minecraft.util.text.TranslationTextComponent;
 import net.minecraft.world.World;
 
 public class LegendHelmetItem extends LegendArmorItem {
   public LegendHelmetItem(IArmorMaterial material, EquipmentSlotType slot, Item.Properties settings) {
     super(material, slot, settings);
   }
 
   
   public void addInformation(ItemStack p_77624_1_, @Nullable World p_77624_2_, List<ITextComponent> tooltip, ITooltipFlag p_77624_4_) {
     tooltip.add(new TranslationTextComponent("tooltip.legendmod.LegendHelmetItem"));
     super.addInformation(p_77624_1_, p_77624_2_, tooltip, p_77624_4_);
   }
 }





