 package de.fab.legendmod.common.material;
 
 import de.fab.legendmod.core.init.ItemInit;
 import java.util.function.Supplier;
 import net.minecraft.inventory.EquipmentSlotType;
 import net.minecraft.item.IArmorMaterial;
 import net.minecraft.item.crafting.Ingredient;
 import net.minecraft.util.IItemProvider;
 import net.minecraft.util.SoundEvent;
 import net.minecraft.util.SoundEvents;
 
 public enum CustomArmorMaterial
   implements IArmorMaterial
 {
   CITRIN_ARMOR("citrin_armor", 3.6D, new int[] { 2, 6, 7, 2 }, 9, SoundEvents.ITEM_ARMOR_EQUIP_IRON, 0.0F, 0.0F, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)ItemInit.CITRIN_INGOT.get()
       
       })),
   NETHER_ARMOR("nether_armor", 4.8D, new int[] { 3, 6, 8, 3 }, 10, SoundEvents.ITEM_ARMOR_EQUIP_IRON, 1.0F, 0.0F, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)ItemInit.NETHER_INGOT.get()
       
       })),
   LEGEND_ARMOR("legend_armor", 9.99999999E8D, new int[] { 3, 6, 8, 3 }, 25, SoundEvents.ITEM_ARMOR_EQUIP_DIAMOND, 2.0F, 0.0F, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)ItemInit.LEGEND_INGOT.get() }));
   
   private static final double[] baseDurability;
   
   private final String name;
   private final double durabilityMultiplier;
   private final int[] armorVal;
   
   static {
     baseDurability = new double[] { 81.25D, 93.75D, 100.0D, 68.75D };
   }
 
   
   private final int enchantability;
   
   private final SoundEvent equipSound;
   
   private final float toughness;
   private final float knockbackResistance;
   private final Ingredient repairIngredient;
   
   CustomArmorMaterial(String name, double durabilityMultiplier, int[] armorVal, int enchantability, SoundEvent equipSound, float toughness, float knockbackResistance, Supplier<Ingredient> repairIngredient) {
     this.name = name;
     this.durabilityMultiplier = durabilityMultiplier;
     this.armorVal = armorVal;
     this.enchantability = enchantability;
     this.equipSound = equipSound;
     this.toughness = toughness;
     this.knockbackResistance = knockbackResistance;
     this.repairIngredient = repairIngredient.get();
   }
 
 
 
   
   public int getDurability(EquipmentSlotType slot) {
     return (int)(baseDurability[slot.getIndex()] * this.durabilityMultiplier);
   }
 
   
   public int getDamageReductionAmount(EquipmentSlotType slot) {
     return this.armorVal[slot.getIndex()];
   }
 
   
   public int getEnchantability() {
     return this.enchantability;
   }
 
   
   public SoundEvent getSoundEvent() {
     return this.equipSound;
   }
 
   
   public Ingredient getRepairMaterial() {
     return this.repairIngredient;
   }
 
   
   public String getName() {
     return this.name;
   }
 
   
   public float getToughness() {
     return this.toughness;
   }

     @Override
     public float getKnockbackResistance() {
         return knockbackResistance;
     }

 }




 
 