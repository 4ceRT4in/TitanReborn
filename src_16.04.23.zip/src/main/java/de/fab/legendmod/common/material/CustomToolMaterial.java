 package de.fab.legendmod.common.material;
 
 import de.fab.legendmod.core.init.ItemInit;
 import java.util.function.Supplier;
 import net.minecraft.item.IItemTier;
 import net.minecraft.item.Items;
 import net.minecraft.item.crafting.Ingredient;
 import net.minecraft.util.IItemProvider;
 
 public enum CustomToolMaterial
   implements IItemTier
 {
   WOOD(0, 59, 1.0F, 0.0F, 15, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)Items.OAK_WOOD })),
   GOLD(0, 32, 6.0F, 0.0F, 22, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)Items.GOLD_INGOT })),
   STONE(1, 131, 2.0F, 0.0F, 5, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)Items.STONE })),
   IRON(2, 250, 3.0F, 0.0F, 14, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)Items.IRON_INGOT })),
   DIAMOND(3, 1561, 4.0F, 0.0F, 10, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)Items.DIAMOND })),
   NETHERITE(4, 2031, 5.0F, 0.0F, 15, () -> Ingredient.fromItems(new IItemProvider[] {
         
         (IItemProvider)Items.NETHERITE_INGOT
 
 
       
       })),
   CITRIN(2, 250, 3.0F, 0.0F, 14, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)ItemInit.CITRIN_INGOT.get() })),
   NETHER(2, 375, 3.0F, 0.0F, 14, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)ItemInit.NETHER_INGOT.get() })),
   LEGEND(3, 999999999, 4.0F, 0.0F, 22, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)ItemInit.LEGEND_INGOT.get()
       })),
   CITRIN_GREAT(2, 1000, 3.0F, 0.0F, 14, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)ItemInit.CITRIN_INGOT.get() })),
   NETHER_GREAT(2, 1500, 3.0F, 0.0F, 14, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)ItemInit.NETHER_INGOT.get() })),
   DIAMOND_GREAT(3, 2000, 4.0F, 0.0F, 14, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)Items.DIAMOND })),
   NETHERITE_GREAT(4, 2500, 5.0F, 0.0F, 14, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)Items.NETHERITE_INGOT })),
   LEGEND_GREAT(4, 999999999, 5.0F, 0.0F, 22, () -> Ingredient.fromItems(new IItemProvider[] { (IItemProvider)ItemInit.LEGEND_INGOT.get() }));
 
   
   private final int harvestLevel;
 
   
   private final int maxUses;
   
   private final float efficiency;
   
   private final float attackDamage;
   
   private final int enchantability;
   
   private final Ingredient repairMaterial;
 
   
   CustomToolMaterial(int harvestLevel, int maxUses, float efficiency, float attackDamage, int enchantability, Supplier<Ingredient> repairMaterial) {
     this.harvestLevel = harvestLevel;
     this.maxUses = maxUses;
     this.efficiency = efficiency;
     this.attackDamage = attackDamage;
     this.enchantability = enchantability;
     this.repairMaterial = repairMaterial.get();
   }

   @Override
   public int getMaxUses()  {
     return this.maxUses;
   }

   @Override
   public float getEfficiency()  {
     return this.efficiency;
   }

   @Override
   public float getAttackDamage()  {
     return this.attackDamage;
   }
   @Override
   public int getHarvestLevel()  {
     return this.harvestLevel;
   }

   @Override
   public int getEnchantability()  {
     return this.enchantability;
   }

   @Override
   public Ingredient getRepairMaterial() {
     return this.repairMaterial;
   }
 }




 
 